package madstodolist.service.EquipoTests;

import madstodolist.model.Equipo;
import madstodolist.model.Usuario;
import madstodolist.service.EquipoService;
import madstodolist.service.UsuarioService;
import org.hibernate.LazyInitializationException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EquipoServiceTest {

    @Autowired
    EquipoService equipoService;

    @Autowired
    UsuarioService usuarioService;

    @Test
    public void obtenerListadoEquipos() {
        // GIVEN
        // En el application.properties se cargan los datos de prueba del fichero datos-test.sql

        // WHEN
        List<Equipo> equipos = equipoService.findAllOrderedByName();

        // THEN
        assertThat(equipos).hasSize(2);
        assertThat(equipos.get(0).getNombre()).isEqualTo("Proyecto Adamantium");
        assertThat(equipos.get(1).getNombre()).isEqualTo("Proyecto Cobalto");
    }

    @Test
    public void obtenerEquipo() {
        // GIVEN
        // En el application.properties se cargan los datos de prueba del fichero datos-test.sql

        // WHEN
        Equipo equipo = equipoService.findById(1L);

        // THEN
        assertThat(equipo.getNombre()).isEqualTo("Proyecto Cobalto");
        // Comprobamos que la relación con Usuarios es lazy: al
        // intentar acceder a la colección de usuarios se debe lanzar una
        // excepción de tipo LazyInitializationException.
        assertThatThrownBy(() -> {
            equipo.getUsuarios().size();
        }).isInstanceOf(LazyInitializationException.class);
    }


    @Test
    public void comprobarRelacionUsuarioEquipos() {
        // GIVEN
        // En el application.properties se cargan los datos de prueba del fichero datos-test.sql

        // WHEN
        Usuario usuario = usuarioService.findById(1L);

        // THEN

        assertThat(usuario.getEquipos()).hasSize(1);
    }


    @Test
    public void obtenerUsuariosEquipo() {
        // GIVEN
        // En el application.properties se cargan los datos de prueba del fichero datos-test.sql

        // WHEN
        List<Usuario> usuarios = equipoService.usuariosEquipo(1L);

        // THEN
        assertThat(usuarios).hasSize(1);
        assertThat(usuarios.get(0).getEmail()).isEqualTo("ana.garcia@gmail.com");
        // Comprobamos que la relación entre usuarios y equipos es eager
        // Primero comprobamos que la colección de equipos tiene 1 elemento
        assertThat(usuarios.get(0).getEquipos()).hasSize(1);
        // Y después que el elemento es el equipo Proyecto Cobalto
        assertThat(usuarios.get(0).getEquipos().stream().findFirst().get().getNombre()).isEqualTo("Proyecto Cobalto");
    }

    @Test
    @Transactional
    public void crearEquipo(){
        // GIVEN
        Usuario creador = usuarioService.findById(1L);

        // WHEN
        Equipo equipo = equipoService.crear("PPSS", 1L);

        // THEN
        assertThat(equipo).isNotNull();
        assertThat(creador).isNotNull();
        assertThat(creador.getEquipos()).contains(equipo);
        assertThat(equipo.getUsuarios()).contains(creador);
    }

    @Test
    @Transactional
    public void añadirUsuarioEquipo(){
        // GIVEN
        Equipo equipo = equipoService.findById(2L);
        Usuario usuario = usuarioService.findById(1L);

        // Comprobamos que inicialmente no están relacionados
        assertThat(usuarioService.findById(1L).getEquipos()).doesNotContain(equipo);
        assertThat(equipoService.findById(2L).getUsuarios()).doesNotContain(usuario);

        // WHEN
        equipoService.añadirUsuarioEquipo(1L, 2L);

        // THEN
        assertThat(usuarioService.findById(1L).getEquipos()).contains(equipo);
        assertThat(equipoService.findById(2L).getUsuarios()).contains(usuario);
    }

    @Test
    @Transactional
    public void eliminarUsuarioEquipo(){
        // GIVEN
        Equipo equipo = equipoService.findById(1L);
        Usuario usuario = usuarioService.findById(1L);

        // THEN
        assertThat(usuarioService.findById(1L).getEquipos()).contains(equipo);
        assertThat(equipoService.findById(1L).getUsuarios()).contains(usuario);

        // WHEN
        equipoService.eliminarUsuarioEquipo(1L, 1L);

        // THEN
        assertThat(usuarioService.findById(1L).getEquipos()).doesNotContain(equipo);
        assertThat(equipoService.findById(1L).getUsuarios()).doesNotContain(usuario);
    }


    @Test
    @Transactional
    public void eliminarEquipo(){
        /** TODO: En este tests testearemos lo siguiente...
         *      Un equipo puede ser eliminado de la base de datos con éxito
          */

        // GIVEN
        // Comprobamos que ciertamente la base de datos contiene el equipo con id 1L
        assertThat(equipoService.findById(1L)).isNotNull();

        // THEN

        // WHEN
        equipoService.eliminar(1L);

        // THEN
        assertThat(equipoService.findById(1L)).isNull();
    }

    @Test
    @Transactional
    public void editarNombreEquipo(){
        /** TODO: En este tests testearemos lo siguiente...
         *      Un equipo puede ser editado de la base de datos con éxito
         */

        // GIVEN
        Equipo equipo = equipoService.findById(1L);
        // Comprobamos que ciertamente la base de datos contiene el equipo con id 1L
        assertThat(equipo).isNotNull();

        // THEN
        String oldName = equipo.getNombre();
        String newName = "Nuevo Nombre De Equipo Para Testeo";

        // WHEN
        equipo = equipoService.editar(1L,newName);

        // THEN
        assertThat(equipo).isNotNull();
        assertThat(equipo.getNombre()).isNotNull();
        assertThat(equipo.getNombre()).isEqualTo(newName);
        assertThat(oldName).isNotEqualTo(newName);
        System.out.println("El nombre de equipo ha pasado de \""+oldName+"\" a \""+equipo.getNombre()+'\"');
    }

}