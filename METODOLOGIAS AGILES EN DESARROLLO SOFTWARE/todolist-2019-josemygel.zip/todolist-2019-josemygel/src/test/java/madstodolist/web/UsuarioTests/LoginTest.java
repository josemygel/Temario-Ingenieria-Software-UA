package madstodolist.web.UsuarioTests;

import madstodolist.authentication.ManagerUserSesion;
import madstodolist.controller.LoginController;
import madstodolist.controller.UsuarioController;
import madstodolist.model.Usuario;
import madstodolist.service.UsuarioService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest({LoginController.class, UsuarioController.class})
public class LoginTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UsuarioService usuarioService;

    @MockBean
    private ManagerUserSesion managerUserSesion;

    @MockBean
    private MockHttpSession session;

    /**
     * Las peticiones a la web se realizarán de la siguiente forma
     * SERVICIO + VISTA/ACCIÓN + TIPO USUARIO + OK/KO
     * Siendo OK puede ser una acción permitida correctamente o redirección existosa
     * Siendo KO puede ser una acción denegada o redirección por error
     * Ejemplos:
     * servicioListadoUsuariosAnonimoKO
     * servicioListadoUsuariosNormalKO
     * servicioListadoUsuariosAdminOK
     */


    /**
    * TEST: un usuario normal inicia sesión correctamente siendo redirigido a /usuarios/{id}/tareas
    * */
    @Test
    public void servicioLoginUsuarioOK() throws Exception {

        Usuario anaGarcia = new Usuario("ana.garcia@gmail.com");
        anaGarcia.setId(1L);

        when(usuarioService.login("ana.garcia@gmail.com", "12345678")).thenReturn(UsuarioService.LoginStatus.LOGIN_OK);
        when(usuarioService.findByEmail("ana.garcia@gmail.com")).thenReturn(anaGarcia);

        this.mockMvc.perform(post("/login")
                .param("eMail", "ana.garcia@gmail.com")
                .param("password", "12345678"))
                //.andDo(print())
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/usuarios/1/tareas"));
    }

    /**
     * TEST: un administrador inicia sesión correctamente siendo redirigido a /usuarios
     * */
    @Test
    public void servicioLoginUsuarioAdminOK() throws Exception {

        Usuario anaGarcia = new Usuario("ana.garcia@gmail.com");
        anaGarcia.setId(1L);
        anaGarcia.setIsAdmin(true);

        when(usuarioService.login("ana.garcia@gmail.com", "12345678")).thenReturn(UsuarioService.LoginStatus.LOGIN_OK);
        when(usuarioService.findByEmail("ana.garcia@gmail.com")).thenReturn(anaGarcia);

        this.mockMvc.perform(post("/login")
                .param("eMail", "ana.garcia@gmail.com")
                .param("password", "12345678"))
                //.andDo(print())
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/usuarios"));
    }

    /**
     * ERROR TEST: la página login muestra un mensaje cuando recibe el atributo error de "Contraseña incorrecta"
     * */
    @Test
    public void errorLoginPasswordIncorrectaKO() throws Exception {
        this.mockMvc.perform(get("/login")
                .flashAttr("error", "Contraseña incorrecta"))
                //.andDo(print())
                .andExpect(content().string(containsString("Contraseña incorrecta")));
    }

    /**
     * ERROR TEST: la página login muestra un mensaje cuando recibe el atributo error de "No existe usuario"
     * */
    @Test
    public void errorLoginUsuarioNotFoundKO() throws Exception {
        this.mockMvc.perform(get("/login")
                .flashAttr("error", "No existe usuario"))
                //.andDo(print())
                .andExpect(content().string(containsString("No existe usuario")));
    }

    /**
     * ERROR TEST: la página login muestra un mensaje cuando recibe el atributo error 'personalizado'
     * */
    @Test
    public void errorLoginMensajePersonalizadoKO() throws Exception {
        String error = "Este es un mensaje de error personalizado para comprobar que funciona";
        this.mockMvc.perform(get("/login")
                .flashAttr("error", error))
                //.andDo(print())
                .andExpect(content().string(containsString(error)));
    }

    /**
     * ERROR TEST: un usuario bloqueado no puede iniciar sesión, recibiendo el mensaje 'Tu cuenta está bloqueada'
     * */
    @Test
    public void errorLoginUsuarioBloqueadoKO() throws Exception {

        Usuario anaGarcia = new Usuario("ana.garcia@gmail.com");
        anaGarcia.setId(1L);
        anaGarcia.setBanned(true);

        when(usuarioService.login("ana.garcia@gmail.com", "12345678")).thenReturn(UsuarioService.LoginStatus.USER_IS_BLOCK);
        when(usuarioService.findByEmail("ana.garcia@gmail.com")).thenReturn(anaGarcia);

        //No hay redirección, el usuario no ha cambiado de página tras el Login
        this.mockMvc.perform(post("/login")
                .param("eMail", "ana.garcia@gmail.com")
                .param("password", "12345678"))
                //.andDo(print())
                .andExpect(content().string(containsString("Tu cuenta está bloqueada")));
    }

    /**
     * TEST: un usuario quiere iniciar sesión PERO el usuario (correo) no existe
     * */
    @Test
    public void servicioLoginUsuarioNotFoundKO() throws Exception {

        when(usuarioService.login("pepito.perez@gmail.com", "12345678")).thenReturn(UsuarioService.LoginStatus.USER_NOT_FOUND);

        this.mockMvc.perform(post("/login")
                .param("eMail","pepito.perez@gmail.com")
                .param("password","12345678"))
                //.andDo(print())
                .andExpect(content().string(containsString("No existe usuario")));
    }

    /**
     * TEST: un usuario quiere iniciar sesión PERO la contraseña es incorrecta
     * */
    @Test
    public void servicioLoginUsuarioPasswordKO() throws Exception {

        when(usuarioService.login("ana.garcia@gmail.com", "000")).thenReturn(UsuarioService.LoginStatus.ERROR_PASSWORD);

        this.mockMvc.perform(post("/login")
                .param("eMail","ana.garcia@gmail.com")
                .param("password","000"))
                //.andDo(print())
                .andExpect(content().string(containsString("Contraseña incorrecta")));
    }

    /**
     * TEST: un usuario bloqueado recibe un mensaje con la dirección del administrador para contactar con él
     */
    @Test
    public void servicioLoginUsuarioErrorBloqueadoConAdmin() throws Exception {
        Usuario admin = new Usuario("admin@admin");
        admin.setIsAdmin(true);
        admin.setId(6L);

        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.login("ana.garcia@gmail.com", "000")).thenReturn(UsuarioService.LoginStatus.USER_IS_BLOCK);

        this.mockMvc.perform(post("/login")
                .param("eMail","ana.garcia@gmail.com")
                .param("password","000"))
                //.andDo(print())
                .andExpect(content().string(containsString("Tu cuenta está bloqueada, contacta con admin@admin")));
    }

}
