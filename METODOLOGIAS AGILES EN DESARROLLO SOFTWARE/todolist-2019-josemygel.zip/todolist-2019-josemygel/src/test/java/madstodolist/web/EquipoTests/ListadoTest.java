package madstodolist.web.EquipoTests;

import madstodolist.authentication.ManagerUserSesion;
import madstodolist.controller.EquipoController;
import madstodolist.model.Equipo;
import madstodolist.model.Usuario;
import madstodolist.service.EquipoService;
import madstodolist.service.UsuarioService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(EquipoController.class)
public class ListadoTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EquipoService equipoService;

    @MockBean
    private UsuarioService usuarioService;

    @MockBean
    private ManagerUserSesion managerUserSesion;

    @MockBean
    private MockHttpSession session;

    /**
     * TEST: Se muestra listado de usuarios solo con usuarios no bloqueados
     * */
    @Test
    public void vistaListadoEquiposOK() throws Exception {

        Usuario admin = new Usuario("admin@ua.es");
        admin.setId(1L);
        admin.setNombre("Admin");
        admin.setIsAdmin(true);

        Equipo equipo1 = new Equipo("Equipo1");
        equipo1.setId(1L);

        Equipo equipo2 = new Equipo("Equipo2");
        equipo2.setId(2L);

        List<Usuario> usuarios = new ArrayList<Usuario>();
        usuarios.add(admin);

        List<Equipo> equipos = new ArrayList<Equipo>();
        equipos.add(equipo1);
        equipos.add(equipo2);

        managerUserSesion.logearUsuario(session,admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);

        when(equipoService.findAllOrderedByName()).thenReturn(equipos);

        this.mockMvc.perform(get("/equipos").session(session))
                //.andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Equipo1")))
                .andExpect(content().string(containsString("Equipo2")))
                .andExpect(content().string(not(containsString("Equipo3"))));
    }

    /**
     * TEST: vista para crear un nuevo equipo
     * */
    @Test
    public void vistaCrearNuevoEquipoOK() throws Exception {
        Usuario usuario = new Usuario("user@ua.es");
        usuario.setId(1L);
        usuario.setNombre("user");

        Equipo equipo = new Equipo("Equipo1");
        equipo.setId(1L);

        equipo.addUsuario(usuario);

        managerUserSesion.logearUsuario(session, usuario);
        when(usuarioService.getSesion(session)).thenReturn(usuario);
        when(usuarioService.getAdmin()).thenReturn(usuario);


        this.mockMvc.perform(get("/equipos/crear").session(session))
                //.andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Nueva equipo creado por " + usuario.getNombre())))
                .andExpect(content().string(containsString("Nombre del equipo:")));
    }

    /**
     * TEST: nuevo equipo creado
     * */
    @Test
    public void servicioCrearEquipoPorUsuaroOK() throws Exception {
        Usuario usuario = new Usuario("user@ua.es");
        usuario.setId(2L);
        usuario.setNombre("user");

        Equipo equipo = new Equipo("Equipo1");
        equipo.setId(1L);

        equipo.addUsuario(usuario);

        managerUserSesion.logearUsuario(session, usuario);
        when(usuarioService.getSesion(session)).thenReturn(usuario);
        when(usuarioService.getAdmin()).thenReturn(usuario);

        when(equipoService.crear("Equipo1",2L)).thenReturn(equipo);

        this.mockMvc.perform(post("/equipos/crear").session(session)
                .param("nombre",equipo.getNombre()))
                //.andDo(print())
                .andExpect(flash().attribute("mensaje","Equipo " + equipo.getNombre() + " creado correctamente"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/equipos"));
    }

    /**
     * TEST: alta de un usuario desde listado devuelve al listado con mensaje de coorecto
     * */
    @Test
    public void servicioAltaUsuarioEnEquipoDesdeListadoOK() throws Exception {
        Usuario usuario = new Usuario("user@ua.es");
        usuario.setId(1L);
        usuario.setNombre("user");

        Equipo equipo = new Equipo("Equipo1");
        equipo.setId(1L);

        equipo.addUsuario(usuario);

        managerUserSesion.logearUsuario(session, usuario);
        when(usuarioService.getSesion(session)).thenReturn(usuario);
        when(usuarioService.getAdmin()).thenReturn(usuario);
        when(usuarioService.getAdmin()).thenReturn(usuario);
        when(equipoService.findById(1L)).thenReturn(equipo);

        this.mockMvc.perform(get("/equipos/1/alta").session(session))
                //.andDo(print())
                .andExpect(flash().attribute("mensaje","Te has unido al equipo " + equipo.getNombre()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/equipos"));
    }

    /**
     * TEST: alta de un usuario desde listado devuelve al listado con mensaje de coorecto
     * */
    @Test
    public void servicioBajaUsuarioEnEquipoDesdeListadoOK() throws Exception {
        Usuario usuario = new Usuario("user@ua.es");
        usuario.setId(1L);
        usuario.setNombre("user");

        Equipo equipo = new Equipo("Equipo1");
        equipo.setId(1L);

        equipo.addUsuario(usuario);

        managerUserSesion.logearUsuario(session, usuario);
        when(usuarioService.getSesion(session)).thenReturn(usuario);
        when(usuarioService.getAdmin()).thenReturn(usuario);
        when(usuarioService.getAdmin()).thenReturn(usuario);
        when(equipoService.findById(1L)).thenReturn(equipo);

        this.mockMvc.perform(get("/equipos/1/baja").session(session))
                //.andDo(print())
                .andExpect(flash().attribute("mensaje","Te has borrado del equipo " + equipo.getNombre()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/equipos"));
    }

}
