package madstodolist.web.EquipoTests;

import madstodolist.authentication.ManagerUserSesion;
import madstodolist.controller.EquipoController;
import madstodolist.model.Equipo;
import madstodolist.model.Usuario;
import madstodolist.service.EquipoService;
import madstodolist.service.UsuarioService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(EquipoController.class)
public class EditarTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EquipoService equipoService;

    @MockBean
    private UsuarioService usuarioService;

    @MockBean
    private ManagerUserSesion managerUserSesion;

    @MockBean
    private MockHttpSession session;

    @Test
    public void vistaEditarEquipoUsuarioNormalKO() throws Exception{
        // GIVEN
        Usuario usuario = new Usuario("usuario@gmail.com");
        usuario.setNombre("usuario");
        usuario.setId(1L);
        usuario.setIsAdmin(false);

        Usuario admin = new Usuario("admin@gmail.com");
        admin.setNombre("admin");
        admin.setId(2L);
        admin.setIsAdmin(true);

        Equipo equipo = new Equipo("Equipo 1");
        equipo.setId(1L);

        // WHEN
        managerUserSesion.logearUsuario(session,usuario);
        when(usuarioService.getSesion(session)).thenReturn(usuario);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findById(1L)).thenReturn(usuario);
        when(usuarioService.findById(2L)).thenReturn(admin);
        when(equipoService.findById(1L)).thenReturn(equipo);

        // THEN
        this.mockMvc.perform(get("/equipos/1/editar").session(session))
                //.andDo(print())
                .andExpect(status().isUnauthorized());
    }
    @Test
    public void vistaEditarEquipoAdministradorOK() throws Exception{
        // GIVEN
        Usuario admin = new Usuario("admin@gmail.com");
        admin.setNombre("admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        Equipo equipo = new Equipo("equipo1");
        equipo.setId(1L);

        // WHEN
        managerUserSesion.logearUsuario(session,admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findById(1L)).thenReturn(admin);
        when(equipoService.findById(1L)).thenReturn(equipo);

        // THEN
        this.mockMvc.perform(get("/equipos/1/editar").session(session))
                //.andDo(print())
                .andExpect(content().string(containsString("Guardar")))
                .andExpect(content().string(containsString("Cancelar"))); //El usuario logueado no es admin, por lo que no podrá gestionar el equipo
    }

    @Test
    public void servicioEditarEquipoUsuarioNormalKO() throws Exception{
        // GIVEN
        Usuario usuario = new Usuario("usuario@gmail.com");
        usuario.setNombre("usuario");
        usuario.setId(1L);
        usuario.setIsAdmin(false);

        Usuario admin = new Usuario("admin@gmail.com");
        admin.setNombre("admin");
        admin.setId(2L);
        admin.setIsAdmin(true);

        managerUserSesion.logearUsuario(session,usuario);
        when(usuarioService.getSesion(session)).thenReturn(usuario);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findById(1L)).thenReturn(usuario);

        this.mockMvc.perform(post("/equipos/1/editar").session(session))
                //.andDo(print())
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void servicioEditarEquipoAdministradorOK() throws Exception{
        // GIVEN
        Usuario admin = new Usuario("admin@gmail.com");
        admin.setNombre("admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        Equipo equipo = new Equipo("equipo1");
        equipo.setId(1L);

        // WHEN
        managerUserSesion.logearUsuario(session,admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findById(1L)).thenReturn(admin);
        when(equipoService.findById(1L)).thenReturn(equipo);

        // THEN
        this.mockMvc.perform(post("/equipos/1/editar").session(session))
                //.andDo(print())
                .andExpect(flash().attribute("mensaje","Equipo renombrado correctamente"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/equipos/1"));
    }

}