package madstodolist.controller;

public class EquipoData {
    private String nombre;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) { this.nombre = nombre; }
}
