package madstodolist.controller;

import madstodolist.authentication.ManagerUserSesion;
import madstodolist.authentication.UsuarioNoAdminException;
import madstodolist.authentication.UsuarioNoLogeadoException;
import madstodolist.controller.exception.EquipoNotFoundException;
import madstodolist.controller.exception.UsuarioNotFoundException;
import madstodolist.model.Equipo;
import madstodolist.model.Usuario;
import madstodolist.service.EquipoService;
import madstodolist.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class EquipoController {
    public String mensaje;

    @Autowired
    UsuarioService usuarioService;

    @Autowired
    EquipoService equipoService;

    @Autowired
    ManagerUserSesion managerUserSesion;

    @GetMapping("/equipos")
    public String listadoEquipos(Model model, HttpSession session) {
        Usuario uLogued = usuarioService.getSesion(session);

        //Solo admin puede entrar aquí
        //TODO: Averiguar por que no salta la excepcion, y se precisa del condicional siguiente
        managerUserSesion.comprobarUsuarioLogeado(session, uLogued);

        //TODO: Esta excepcion deberia saltar dentro del manager
        if (uLogued != null) {
            model.addAttribute("usuario", uLogued);
        }else{
            throw new UsuarioNoLogeadoException();
        }

        //Obtenemos la lista de equipos
        List<Equipo> equipos = equipoService.findAllOrderedByName();
        model.addAttribute("equipos", equipos);

        return "listaEquipos";
    }


    @GetMapping("/equipos/{id}")
    public String detallesEquipo(@PathVariable(value="id") Long idDetalles, Model model, HttpSession session) {
        Usuario uLogued = usuarioService.getSesion(session);

        managerUserSesion.comprobarUsuarioLogeado(session, uLogued);

        Equipo eDetalles = equipoService.findById(idDetalles);

        if (uLogued != null) {
            model.addAttribute("usuario", uLogued);
        }else{
            throw new UsuarioNoLogeadoException();
        }

        if(eDetalles == null) {
            //Obtenemos la lista de usuarios
            List<Equipo> equipos = equipoService.findAllOrderedByName();
            model.addAttribute("equipos", equipos);
            return "redirect:/equipos";
        }else{
            model.addAttribute("eDetalles", eDetalles);
            model.addAttribute("usuarios", equipoService.usuariosEquipo(eDetalles.getId()));
            return "detallesEquipo";
        }
    }

    @GetMapping("/equipos/crear")
    public String crearEquipo(@ModelAttribute EquipoData equipoData,
                              Model model, HttpSession session) {
        Usuario uLogued = usuarioService.getSesion(session);

        managerUserSesion.comprobarUsuarioLogeado(session, uLogued);

        if (uLogued != null) {
            model.addAttribute("usuario", uLogued);
        }else{
            throw new UsuarioNoLogeadoException();
        }

        return "formNuevoEquipo";
    }

    @PostMapping("/equipos/crear")
    public String altaEquipo(@ModelAttribute EquipoData equipoData, Model model, RedirectAttributes flash, HttpSession session) {

        Usuario uLogued = usuarioService.getSesion(session);

        managerUserSesion.comprobarUsuarioLogeado(session, uLogued);

        if (uLogued == null) {
            throw new UsuarioNotFoundException();
        }

        Equipo equipo = equipoService.crear(equipoData.getNombre(), uLogued.getId());

        flash.addFlashAttribute("mensaje", "Equipo " + equipo.getNombre() + " creado correctamente");
        return "redirect:/equipos";
    }

    @GetMapping({"/equipos/{id}/alta", "/equipos/{id}/alta/{detalles}"})
    public String altaEquipo(@PathVariable(value="id") Long idEquipo, @PathVariable(value = "detalles", required = false) Boolean detalles, @ModelAttribute EquipoData equipoData, RedirectAttributes flash, Model model, HttpSession session) {
        Usuario uLogued = usuarioService.getSesion(session);
        Equipo equipo = equipoService.findById(idEquipo);

        managerUserSesion.comprobarUsuarioLogeado(session,uLogued);

        if (uLogued == null) {
            throw new UsuarioNoLogeadoException();
        }else if(equipo == null) {
            throw new EquipoNotFoundException();
        }

        model.addAttribute("usuario", uLogued);

        equipoService.añadirUsuarioEquipo(uLogued.getId(), idEquipo);
        flash.addFlashAttribute("mensaje", "Te has unido al equipo " + equipo.getNombre());

        return detalles != null && detalles == true ? "redirect:/equipos/"+idEquipo : "redirect:/equipos";
    }

    @GetMapping({"/equipos/{id}/baja", "/equipos/{id}/baja/{detalles}"})
    public String bajaEquipo(@PathVariable(value="id") Long idEquipo, @PathVariable(value="detalles", required = false) Boolean detalles, @ModelAttribute EquipoData equipoData, RedirectAttributes flash, Model model, HttpSession session) {
        Usuario uLogued = usuarioService.getSesion(session);
        Equipo equipo = equipoService.findById(idEquipo);

        managerUserSesion.comprobarUsuarioLogeado(session,uLogued);

        if (uLogued == null) {
            throw new UsuarioNoLogeadoException();
        }else if(equipo == null) {
            throw new EquipoNotFoundException();
        }

        model.addAttribute("usuario", uLogued);

        equipoService.eliminarUsuarioEquipo(uLogued.getId(), idEquipo);
        flash.addFlashAttribute("mensaje", "Te has borrado del equipo " + equipo.getNombre());

        return detalles != null && detalles == true ? "redirect:/equipos/"+idEquipo : "redirect:/equipos";
    }

    @GetMapping("/equipos/{idEquipo}/bloquear/{idUsuario}")
    public String bloquearUsuarioDesdeEquipoDetalles(@PathVariable(value = "idEquipo") Long idEquipo, @PathVariable(value="idUsuario") Long idUsuario, RedirectAttributes flash, HttpSession session) {
        Usuario uLogued = usuarioService.getSesion(session);

        //Solo admin puede entrar aquí
        managerUserSesion.comprobarUsuarioAdmin(session, uLogued);

        if (uLogued == null) {
            throw new UsuarioNoLogeadoException();
        }
        else if(!uLogued.equals(usuarioService.getAdmin())) {
            throw new UsuarioNoAdminException();
        }

        Usuario usuario = usuarioService.findById(idUsuario);
        Boolean isBanned = usuarioService.bloquear(idUsuario);

        String mensaje = isBanned
                ? "¡El usuario " + usuario.getEmail() + " ha sido bloqueado correctamente!"
                : "¡El usuario " + usuario.getEmail() + " ha sido desbloqueado correctamente!";

        flash.addFlashAttribute("mensaje", mensaje);

        return "redirect:/equipos/"+idEquipo;
    }

    @GetMapping("/equipos/{id}/editar")
    public String formEditaEquipo(@PathVariable(value="id") Long idEquipo, @ModelAttribute EquipoData equipoData,
                                 Model model, HttpSession session) throws Exception{
        Usuario uLogued = usuarioService.getSesion(session);
        //Solo admin puede entrar aquí
        managerUserSesion.comprobarUsuarioAdmin(session, uLogued);

        if (uLogued == null) {
            throw new UsuarioNoLogeadoException();
        }
        else if(!uLogued.equals(usuarioService.getAdmin())) {
            throw new UsuarioNoAdminException();
        }

        Equipo equipo = equipoService.findById(idEquipo);

        if (equipo == null) {
            throw new EquipoNotFoundException();
        }

        model.addAttribute("equipo", equipo);
        model.addAttribute("usuario", uLogued);
        equipoData.setNombre(equipo.getNombre());

        return "formEditarEquipo";
    }

    @PostMapping("/equipos/{id}/editar")
    public String modificarEquipo(@PathVariable(value="id") Long idEquipo, @ModelAttribute EquipoData equipoData,
                                       Model model, RedirectAttributes flash, HttpSession session) {
        Usuario uLogued = usuarioService.getSesion(session);
        //Solo admin puede entrar aquí
        managerUserSesion.comprobarUsuarioAdmin(session, uLogued);

        if (uLogued == null) {
            throw new UsuarioNoLogeadoException();
        }
        else if(!uLogued.equals(usuarioService.getAdmin())) {
            throw new UsuarioNoAdminException();
        }

        Equipo equipo = equipoService.findById(idEquipo);

        if (equipo == null) {
            throw new EquipoNotFoundException();
        }

        equipoService.editar(idEquipo, equipoData.getNombre());
        flash.addFlashAttribute("mensaje", "Equipo renombrado correctamente");

        return "redirect:/equipos/" + equipo.getId();
    }

    @GetMapping("/equipos/{id}/delete")
    public String eliminarEquipo(@PathVariable(value="id") Long idEquipo, Model model, HttpSession session, RedirectAttributes flash) throws Exception{
        Usuario uLogued = usuarioService.getSesion(session);
        //Solo admin puede entrar aquí
        managerUserSesion.comprobarUsuarioAdmin(session, uLogued);

        if (uLogued == null) {
            throw new UsuarioNoLogeadoException();
        }
        else if(!uLogued.equals(usuarioService.getAdmin())) {
            throw new UsuarioNoAdminException();
        }

        equipoService.eliminar(idEquipo);
        List<Equipo> equipos = equipoService.findAllOrderedByName();

        model.addAttribute("equipos", equipos);
        model.addAttribute("usuario", uLogued);
        flash.addFlashAttribute("mensaje", "Equipo eliminado correctamente");

        return "redirect:/equipos";
    }
}

