package madstodolist.service;

import madstodolist.controller.exception.EquipoNotFoundException;
import madstodolist.controller.exception.UsuarioNotFoundException;
import madstodolist.model.Equipo;
import madstodolist.model.EquipoRepository;
import madstodolist.model.Usuario;
import madstodolist.model.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class EquipoService {

    private EquipoRepository equipoRepository;

    private UsuarioRepository usuarioRepository;

    @Autowired
    public EquipoService(EquipoRepository equipoRepository, UsuarioRepository usuarioRepository) {
        this.equipoRepository = equipoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @Transactional(readOnly = true)
    public List<Equipo> findAllOrderedByName() {
        List<Equipo> equipos = equipoRepository.findAll();

        //Ordenar alfabéticamente SIN importar mayusculas/minusculas
        Collections.sort(equipos, (a, b) -> a.getNombre().compareToIgnoreCase(b.getNombre()));
        return equipos;
    }

    @Transactional(readOnly = true)
    public Equipo findById(long id) { return equipoRepository.findById(id).orElse(null); }

    @Transactional(readOnly = true)
    public List<Usuario> usuariosEquipo(Long idEquipo){
        Equipo equipo = equipoRepository.findById(idEquipo).orElse(null);

        if (equipo == null) {
            throw new EquipoServiceException("No existe equipo con id " + idEquipo);
        }

        return new ArrayList<Usuario>(equipo.getUsuarios());
    }

    @Transactional
    public void añadirUsuarioEquipo(long idUsuario, long idEquipo) {
        Equipo equipo = equipoRepository.findById(idEquipo).orElse(null);
        Usuario usuario = usuarioRepository.findById(idUsuario).orElse(null);

        if(equipo == null){
            throw new EquipoNotFoundException();
        }else if(usuario == null){
            throw new UsuarioNotFoundException();
        }

        equipo.addUsuario(usuario);
        // equipoRepository.save(equipo); <=> No es necesario el save ya que se actualiza la tabla join
    }

    @Transactional
    public void eliminarUsuarioEquipo(long idUsuario, long idEquipo) {
        Equipo equipo = equipoRepository.findById(idEquipo).orElse(null);
        Usuario usuario = usuarioRepository.findById(idUsuario).orElse(null);

        if(equipo == null){
            throw new EquipoNotFoundException();
        }else if(usuario == null){
            throw new UsuarioNotFoundException();
        }

        equipo.removeUsuario(usuario);
    }

    @Transactional
    public Equipo crear(String equipoNombre, Long idUsuario) {
        Usuario creador = usuarioRepository.findById(idUsuario).orElse(null);

        if (creador == null) {
            throw new TareaServiceException("Usuario " + idUsuario + " no existe al crear el equipo " + equipoNombre);
        }

        Equipo equipo = new Equipo(equipoNombre);
        equipoRepository.save(equipo);

        equipo.addUsuario(creador);

        return equipo;
    }

    @Transactional
    public void eliminar(long idEquipo) {
        Equipo equipo = equipoRepository.findById(idEquipo).orElse(null);
        if (equipo == null) {
            throw new EquipoServiceException("No existe el equipo con id " + idEquipo);
        }

        equipoRepository.delete(equipo);
    }

    @Transactional
    public Equipo editar(long idEquipo, String nombre) {
        Equipo equipo = equipoRepository.findById(idEquipo).orElse(null);

        if (equipo == null) {
            throw new EquipoServiceException("No existe el equipo con id " + idEquipo);
        }

        equipo.setNombre(nombre);
        equipoRepository.save(equipo);

        return equipo;
    }
}
