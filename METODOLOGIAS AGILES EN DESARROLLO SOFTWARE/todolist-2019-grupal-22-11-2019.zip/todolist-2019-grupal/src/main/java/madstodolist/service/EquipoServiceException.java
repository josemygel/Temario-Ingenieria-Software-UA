package madstodolist.service;

public class EquipoServiceException extends RuntimeException {

    public EquipoServiceException(String message) {
        super(message);
    }
}
