package madstodolist.controller;

import madstodolist.authentication.ManagerUserSesion;
import madstodolist.authentication.UsuarioNoAdminException;
import madstodolist.authentication.UsuarioNoLogeadoException;
import madstodolist.model.Usuario;
import madstodolist.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class UsuarioController {

    @Autowired
    UsuarioService usuarioService;

    @Autowired
    ManagerUserSesion managerUserSesion;

    @GetMapping("/usuarios")
    public String listadoUsuarios(Model model, HttpSession session) {
        Usuario uLogued = usuarioService.getSesion(session);

        //Solo admin puede entrar aquí
        //TODO: Averiguar por que no salta la excepcion, y se precisa del condicional siguiente
        managerUserSesion.comprobarUsuarioAdmin(session, uLogued);

        //TODO: Esta excepcion deberia saltar dentro del manager
        if(!uLogued.equals(usuarioService.getAdmin())) {
            throw new UsuarioNoAdminException();
        }

        if (uLogued != null) {
            model.addAttribute("usuario", uLogued);
        }

        //Obtenemos la lista de usuarios
        List<Usuario> usuarios = usuarioService.findAll();
        model.addAttribute("usuarios",usuarios);

        return "listaUsuarios";
    }

    @GetMapping("/usuarios/{id}")
    public String detallesUsuario(@PathVariable(value="id") Long idDetalles, Model model, HttpSession session) {

        Usuario uLogued = usuarioService.getSesion(session);

        //Solo admin puede entrar aquí
        //TODO: Averiguar por que no salta la excepcion, y se precisa del condicional siguiente
        managerUserSesion.comprobarUsuarioAdmin(session, uLogued);

        //TODO: Esta excepcion deberia saltar dentro del manager
        if(uLogued == null || !uLogued.equals(usuarioService.getAdmin())) {
            throw new UsuarioNoAdminException();
        }

        Usuario uDetalles = usuarioService.findById(idDetalles);

        if (uLogued != null) {
            model.addAttribute("usuario", uLogued);
        }

        if(uDetalles == null) {
            //Obtenemos la lista de usuarios
            List<Usuario> usuarios = usuarioService.findAll();
            model.addAttribute("usuarios", usuarios);
            return "redirect:/usuarios";
        }else{
            model.addAttribute("uDetalles",uDetalles);
            return "detallesUsuario";
        }
    }

    @GetMapping("/bloquear/{id}")
    public String bloquearUsuario(@PathVariable(value="id") Long idUsuario, RedirectAttributes flash, HttpSession session) {

        Usuario uLogued = usuarioService.getSesion(session);

        //Solo admin puede entrar aquí
        //TODO: Averiguar por que no salta la excepcion, y se precisa del condicional siguiente
        managerUserSesion.comprobarUsuarioAdmin(session, uLogued);


        if (uLogued == null) {
            throw new UsuarioNoLogeadoException();
        }
        //TODO: Esta excepcion deberia saltar dentro del manager
        else if(!uLogued.equals(usuarioService.getAdmin())) {
            throw new UsuarioNoAdminException();
        }


        Usuario usuario = usuarioService.findById(idUsuario);
        //TODO: HACER TEST DE BLOQUEOS!
        Boolean isBanned = usuarioService.bloquear(idUsuario);

        String mensaje = isBanned
                    ? "¡El usuario " + usuario.getEmail() + " ha sido bloqueado correctamente!"
                    : "¡El usuario " + usuario.getEmail() + " ha sido desbloqueado correctamente!";

        flash.addFlashAttribute("mensaje", mensaje);
        flash.addFlashAttribute("usuarios", usuarioService.findAll());


        return "redirect:/usuarios";
    }
    @GetMapping("/usuarios/{id}/bloquear")
    public String bloquearUsuarioDesdeDetalles(@PathVariable(value="id") Long idUsuario, RedirectAttributes flash, HttpSession session) {

        Usuario uLogued = usuarioService.getSesion(session);

        //Solo admin puede entrar aquí
        //TODO: Averiguar por que no salta la excepcion, y se precisa del condicional siguiente
        managerUserSesion.comprobarUsuarioAdmin(session, uLogued);


        if (uLogued == null) {
            throw new UsuarioNoLogeadoException();
        }
        //TODO: Esta excepcion deberia saltar dentro del manager
        else if(!uLogued.equals(usuarioService.getAdmin())) {
            throw new UsuarioNoAdminException();
        }

        Usuario usuario = usuarioService.findById(idUsuario);
        //TODO: HACER TEST DE BLOQUEOS!
        Boolean isBanned = usuarioService.bloquear(idUsuario);

        String mensaje = isBanned
                ? "¡El usuario " + usuario.getEmail() + " ha sido bloqueado correctamente!"
                : "¡El usuario " + usuario.getEmail() + " ha sido desbloqueado correctamente!";

        flash.addFlashAttribute("mensaje", mensaje);

        return "redirect:/usuarios/"+usuario.getId();
    }
}

