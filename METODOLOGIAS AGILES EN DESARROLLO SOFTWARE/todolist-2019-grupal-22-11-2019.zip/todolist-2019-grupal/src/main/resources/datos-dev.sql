
/* Populate tables */
INSERT INTO usuarios (id, email, nombre, password, fecha_nacimiento, is_admin, banned) VALUES('1', 'domingo@ua.es', 'Domingo Gallardo', '123', '2001-02-10', false, false);
INSERT INTO usuarios (id, email, nombre, password, fecha_nacimiento, is_admin, banned) VALUES('2', 'admin@admin', 'Admin', 'admin', '1900-01-01', true, false);
INSERT INTO usuarios (id, email, nombre, password, fecha_nacimiento, is_admin, banned) VALUES('3', 'jmgl@alu.ua.es', 'Jose Miguel Gómez Lozano', '123', '2001-02-10', false, false);
INSERT INTO usuarios (id, email, nombre, password, fecha_nacimiento, is_admin, banned) VALUES('4', 'pp@alu.ua.es', 'Pepe', '123', '2001-02-10', false, false);
INSERT INTO usuarios (id, email, nombre, password, fecha_nacimiento, is_admin, banned) VALUES('5', 'H4CK@au.se', 'UNH4CK3R', '321', '2001-02-10', false, true);
INSERT INTO tareas (id, titulo, usuario_id) VALUES('1', 'Lavar coche', '1');
INSERT INTO tareas (id, titulo, usuario_id) VALUES('2', 'Renovar DNI', '1');
