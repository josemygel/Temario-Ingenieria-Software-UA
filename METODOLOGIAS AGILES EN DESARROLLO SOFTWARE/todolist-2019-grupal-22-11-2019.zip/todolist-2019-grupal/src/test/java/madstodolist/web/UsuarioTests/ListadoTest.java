package madstodolist.web.UsuarioTests;

import madstodolist.authentication.ManagerUserSesion;
import madstodolist.controller.LoginController;
import madstodolist.controller.UsuarioController;
import madstodolist.model.Usuario;
import madstodolist.service.UsuarioService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest({LoginController.class, UsuarioController.class})
public class ListadoTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UsuarioService usuarioService;

    @MockBean
    private ManagerUserSesion managerUserSesion;

    @MockBean
    private MockHttpSession session;

    /**
     * TEST: Se muestra listado de usuarios solo con usuarios no bloqueados
     * */
    @Test
    public void vistaListadoUsuariosNoBloqueadosOK() throws Exception {
        Usuario usuario1 = new Usuario("usuario1@ua.es");
        usuario1.setId(1L);
        usuario1.setNombre("Usuario1");

        Usuario usuario2 = new Usuario("usuario2@ua.es");
        usuario2.setId(2L);
        usuario2.setNombre("Usuario2");

        Usuario admin = new Usuario("admin@ua.es");
        admin.setId(5L);
        admin.setNombre("Admin");
        admin.setIsAdmin(true);


        List<Usuario> users = new ArrayList<Usuario>();

        users.add(usuario1);
        users.add(usuario2);
        users.add(admin);

        managerUserSesion.logearUsuario(session,admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findAll()).thenReturn(users);

        this.mockMvc.perform(get("/usuarios").session(session))
                //.andDo(print())
                .andExpect(content().string(not(containsString("Desbloquear")))) //NO HAY Desbloqueos (todos desbloqueados ya)
                .andExpect(content().string(containsString("Bloquear")))         //Bloqueos
                .andExpect(content().string(containsString("Administrador")));   //Inbloqueable
    }

    /**
     * TEST: Se muestra listado de usuarios solo con usuarios bloqueados
     * */
    @Test
    public void vistaListadoUsuariosSoloBloqueadosOK() throws Exception {

        Usuario usuario1 = new Usuario("usuario1@ua.es");
        usuario1.setId(1L);
        usuario1.setNombre("Usuario1");
        usuario1.setBanned(true);

        Usuario usuario2 = new Usuario("usuario2@ua.es");
        usuario2.setId(2L);
        usuario2.setNombre("Usuario2");
        usuario2.setBanned(true);

        Usuario admin = new Usuario("admin@ua.es");
        admin.setId(5L);
        admin.setNombre("Admin");
        admin.setBanned(false);
        admin.setIsAdmin(true);

        List<Usuario> users = new ArrayList<Usuario>();
        users.add(usuario1);
        users.add(usuario2);
        users.add(admin);

        managerUserSesion.logearUsuario(session,admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findAll()).thenReturn(users);

        this.mockMvc.perform(get("/usuarios").session(session))
                //.andDo(print())
                .andExpect(content().string(containsString("Desbloquear")))    //Desbloqueos
                .andExpect(content().string(not(containsString("Bloquear"))))  //No hay Bloqueos posibles (todos bloqueados)
                .andExpect(content().string(containsString("Administrador"))); //Inbloqueable
    }

    /**
     * TEST: Se muestra listado de usuarios solo con usuarios bloqueados y desbloqueados
     * */
    @Test
    public void vistaListadoUsuariosBloqueadosConDesbloqueadosOK() throws Exception {

        Usuario usuario1 = new Usuario("usuario1@ua.es");
        usuario1.setId(1L);
        usuario1.setNombre("Usuario1");
        usuario1.setBanned(true);

        Usuario usuario2 = new Usuario("usuario2@ua.es");
        usuario2.setId(2L);
        usuario2.setNombre("Usuario2");
        usuario2.setBanned(false);

        Usuario admin = new Usuario("admin@ua.es");
        admin.setId(3L);
        admin.setNombre("Admin");
        admin.setBanned(false);
        admin.setIsAdmin(true);


        List<Usuario> users = new ArrayList<Usuario>();
        users.add(usuario1);
        users.add(usuario2);
        users.add(admin);


        managerUserSesion.logearUsuario(session,admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findAll()).thenReturn(users);


        this.mockMvc.perform(get("/usuarios").session(session))
                //.andDo(print())
                .andExpect(content().string(containsString("Desbloquear")))     //Desbloqueos
                .andExpect(content().string(containsString("Bloquear")))        //Bloqueos
                .andExpect(content().string(containsString("Administrador")));   //Inbloqueable
    }

    /**
     * TEST: Solo existe el administrador en la base de datos, por lo que no hay Bloqueos ni Desbloqueos disponibles
     * */
    @Test
    public void vistaListadoUsuariosSoloAdminOK() throws Exception {

        Usuario admin = new Usuario("admin@ua.es");
        admin.setId(1L);
        admin.setNombre("Admin");
        admin.setBanned(false);
        admin.setIsAdmin(true);


        List<Usuario> users = new ArrayList<Usuario>();
        users.add(admin);

        managerUserSesion.logearUsuario(session,admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findAll()).thenReturn(users);

        this.mockMvc.perform(get("/usuarios").session(session))
                //.andDo(print())
                .andExpect(content().string(not(containsString("Desbloquear"))))     //Desbloqueos
                .andExpect(content().string(not(containsString("Bloquear"))))        //Bloqueos
                .andExpect(content().string(containsString("Administrador")));   //Inbloqueable
    }

    /**
     * TEST: un usuario normal inicia sesión correctamente siendo redirigido a /usuarios/{id}/tareas
     * */
    @Test
    public void vistaListadoUsuariosNoAdminKO() throws Exception {
        Usuario usuario1 = new Usuario("usuario1@ua.es");
        usuario1.setId(1L);
        usuario1.setNombre("Usuario1");
        usuario1.setIsAdmin(false);

        Usuario usuario2 = new Usuario("usuario2@ua.es");
        usuario2.setId(1L);
        usuario2.setNombre("Usuario2");
        usuario2.setIsAdmin(false);

        Usuario admin = new Usuario("admin@ua.es");
        admin.setId(3L);
        admin.setNombre("Admin");
        admin.setBanned(false);
        admin.setIsAdmin(true);


        List<Usuario> users = new ArrayList<Usuario>();
        users.add(usuario1);
        users.add(usuario2);
        users.add(admin);

        managerUserSesion.logearUsuario(session,usuario1);
        when(usuarioService.getSesion(session)).thenReturn(usuario1);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findAll()).thenReturn(users);

        this.mockMvc.perform(get("/usuarios").session(session))
                //.andDo(print())
                .andExpect(status().isUnauthorized())
                .andExpect(content().string(not(containsString("¡Iniciar sesión!"))))//Usuario logueado
                .andExpect(content().string(not(containsString("Desbloquear"))))     //Desbloqueos
                .andExpect(content().string(not(containsString("Bloquear"))))        //Bloqueos
                .andExpect(content().string(not(containsString("Administrador"))));   //Inbloqueable
    }

    /**
     * TEST: desbloquear un usuario desde listado devuelve al listado
     * */
    @Test
    public void servicioBloquearUsuarioListadoOK() throws Exception {
        Usuario admin = new Usuario("admin@gmail.com");
        admin.setNombre("admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        Usuario anaGarcia = new Usuario("ana.garcia@gmail.com");
        anaGarcia.setId(2L);
        anaGarcia.setNombre("anagar");
        anaGarcia.setIsAdmin(false);
        anaGarcia.setBanned(false);

        List<Usuario> users = new ArrayList<Usuario>();
        users.add(admin);
        users.add(anaGarcia);


        managerUserSesion.logearUsuario(session, admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findAll()).thenReturn(users);
        when(usuarioService.findById(2L)).thenReturn(anaGarcia);
        when(usuarioService.findById(1L)).thenReturn(admin);

        this.mockMvc.perform(get("/bloquear/2").session(session))
                //.andDo(print())
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/usuarios"));
    }


    /**
     * TEST: desbloquear un usuario desde listado devuelve al listado
     * */
    @Test
    public void servicioDesbloquearUsuarioListadoOK() throws Exception {
        Usuario admin = new Usuario("admin@gmail.com");
        admin.setNombre("admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        Usuario anaGarcia = new Usuario("ana.garcia@gmail.com");
        anaGarcia.setId(2L);
        anaGarcia.setNombre("anagar");
        anaGarcia.setIsAdmin(false);
        anaGarcia.setBanned(true);

        List<Usuario> users = new ArrayList<Usuario>();
        users.add(admin);
        users.add(anaGarcia);


        managerUserSesion.logearUsuario(session, admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findAll()).thenReturn(users);
        when(usuarioService.findById(2L)).thenReturn(anaGarcia);
        when(usuarioService.findById(1L)).thenReturn(admin);

        this.mockMvc.perform(get("/bloquear/2").session(session))
                //.andDo(print())
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/usuarios"));
    }

}
