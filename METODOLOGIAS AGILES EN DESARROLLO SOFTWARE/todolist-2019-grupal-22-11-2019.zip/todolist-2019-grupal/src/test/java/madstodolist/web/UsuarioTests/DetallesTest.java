package madstodolist.web.UsuarioTests;

import madstodolist.authentication.ManagerUserSesion;
import madstodolist.controller.LoginController;
import madstodolist.controller.UsuarioController;
import madstodolist.model.Usuario;
import madstodolist.service.UsuarioService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest({LoginController.class, UsuarioController.class})
public class DetallesTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UsuarioService usuarioService;

    @MockBean
    private ManagerUserSesion managerUserSesion;

    @MockBean
    private MockHttpSession session;

    private Usuario admin = new Usuario("administrador@gmail.com");
    private Usuario user = new Usuario("usuarioTest@gmail.com");

    /**
     * Las peticiones a la web se realizarán de la siguiente forma
     * SERVICIO + VISTA/ACCIÓN + TIPO USUARIO + OK/KO
     * Siendo OK puede ser una acción permitida correctamente o redirección existosa
     * Siendo KO puede ser una acción denegada o redirección por error
     * Ejemplos:
     * servicioListadoUsuariosAnonimoKO
     * servicioListadoUsuariosNormalKO
     * servicioListadoUsuariosAdminOK
     */

    /**
     * TEST: La vista de detalles contiene todos los datos
     * USUARIO: usuario normal y sin bloquear
     */
    @Test
    public void vistaDetallesUsuarioNormalNoBloqueadoOK() throws Exception {
        admin.setNombre("Admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        user.setNombre("UserTestName");
        user.setBanned(false);
        user.setId(2L);

        List<Usuario> users = new ArrayList();
        users.add(admin);
        users.add(user);

        //Sesion como administrador
        managerUserSesion.logearUsuario(session, admin);

        //Se compara admin(logueado) y admin(en la base de datos) que se comparan
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);

        when(usuarioService.findById(2L)).thenReturn(user);

        this.mockMvc.perform(get("/usuarios/2").session(session))
                //.andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("2"))) //ID
                .andExpect(content().string(containsString("UserTestName"))) //Nombre
                .andExpect(content().string(containsString("usuarioTest@gmail.com"))) //Email
                .andExpect(content().string(containsString("Bloquear"))) //Banned option
                .andExpect(content().string(containsString("No bloqueado"))); //Banned
    }

    /**
     * TEST: La vista de detalles contiene todos los datos
     * USUARIO: usuario normal y bloqueado
     */
    @Test
    public void vistaDetallesUsuarioNormalBloqueadoOK() throws Exception {
        admin.setNombre("Admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        user.setNombre("UserTestName");
        user.setBanned(true);
        user.setId(2L);

        List<Usuario> users = new ArrayList();
        users.add(admin);
        users.add(user);

        //Sesion como administrador
        managerUserSesion.logearUsuario(session, admin);

        //Se compara admin(logueado) y admin(en la base de datos) que se comparan
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);

        when(usuarioService.findById(2L)).thenReturn(user);

        this.mockMvc.perform(get("/usuarios/2").session(session))
                //.andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("2"))) //ID
                .andExpect(content().string(containsString("UserTestName"))) //Nombre
                .andExpect(content().string(containsString("usuarioTest@gmail.com"))) //Email
                .andExpect(content().string(containsString("Desbloquear"))) //Banned option
                .andExpect(content().string(containsString("Bloqueado"))); //Banned
    }

    /**
     * TEST: NO AUTORIZADO
     */
    @Test
    public void vistaDetallesUsuarioNoAdminKO() throws Exception {
        admin.setNombre("Admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        user.setNombre("UserTestName");
        user.setBanned(true);
        user.setId(2L);

        List<Usuario> users = new ArrayList();
        users.add(admin);
        users.add(user);

        //Sesion como usuario normnal
        managerUserSesion.logearUsuario(session, user);

        //Se compara admin(logueado) y admin(en la base de datos) que se comparan
        when(usuarioService.getSesion(session)).thenReturn(user);
        when(usuarioService.getAdmin()).thenReturn(admin);

        when(usuarioService.findById(1L)).thenReturn(user);

        this.mockMvc.perform(get("/usuarios/1").session(session))
                //.andDo(print())
                .andExpect(status().isUnauthorized());
    }

    /**
     * TEST: ERROR USUARIO ANONIMO EN DETALLES
     */
    @Test
    public void vistaUsuarioAnonimoKO() throws Exception {
        user.setNombre("UserTestName");
        user.setId(1L);

        List<Usuario> users = new ArrayList();
        users.add(admin);
        users.add(user);

        //Sesion como anonimo
        session.removeAttribute("idUsuarioLogueado");

        //Se compara usuario logueado y admin(en la base de datos)
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findById(1L)).thenReturn(user);

        this.mockMvc.perform(get("/usuarios/1").session(session))
                //.andDo(print())
                .andExpect(status().isUnauthorized());
    }

    /**
     *  TEST: Administrador BLOQUEA un usuario
     */
    @Test
    public void accionBloquearUsuarioOK() throws Exception {
        admin.setNombre("Admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        user.setNombre("UserTestName");
        user.setBanned(false);
        user.setId(2L);

        List<Usuario> users = new ArrayList();
        users.add(admin);
        users.add(user);

        //Sesion como administrador
        managerUserSesion.logearUsuario(session, admin);

        //Se compara admin(logueado) y admin(en la base de datos) que se comparan
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);

        when(usuarioService.findById(2L)).thenReturn(user);
        when(usuarioService.bloquear(2L)).thenReturn(!user.getBanned());

        this.mockMvc.perform(get("/usuarios/2/bloquear").session(session))
                //.andDo(print())
                .andExpect(status().is3xxRedirection())
                .andExpect(flash().attribute("mensaje","¡El usuario usuarioTest@gmail.com ha sido bloqueado correctamente!"))
                .andExpect(redirectedUrl("/usuarios/2"));
    }

    /**
     *  TEST: Administrador DESBLOQUEA un usuario
     */
    @Test
    public void accionDesbloquearUsuarioOK() throws Exception {
        admin.setNombre("Admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        user.setNombre("UserTestName");
        user.setBanned(true);
        user.setId(2L);

        List<Usuario> users = new ArrayList();
        users.add(admin);
        users.add(user);

        //Sesion como administrador
        managerUserSesion.logearUsuario(session, admin);

        //Se compara admin(logueado) y admin(en la base de datos) que se comparan
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);

        when(usuarioService.findById(2L)).thenReturn(user);
        when(usuarioService.bloquear(2L)).thenReturn(!user.getBanned());

        this.mockMvc.perform(get("/usuarios/2/bloquear").session(session))
                //.andDo(print())
                .andExpect(status().is3xxRedirection())
                .andExpect(flash().attribute("mensaje","¡El usuario usuarioTest@gmail.com ha sido desbloqueado correctamente!"))
                .andExpect(redirectedUrl("/usuarios/2"));
    }

    /**
     * TEST: ERROR USUARIO ANONIMO EN DETALLES
     */
    @Test
    public void accionAnonimoBloqueaKO() throws Exception {
        admin.setNombre("Admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        user.setNombre("UserTestName");
        user.setId(2L);

        List<Usuario> users = new ArrayList();
        users.add(admin);
        users.add(user);

        //Sesion como anonimo
        session.removeAttribute("idUsuarioLogueado");

        //Se compara usuario logueado y admin(en la base de datos)
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findById(2L)).thenReturn(user);

        when(usuarioService.getAdmin()).thenReturn(admin);

        this.mockMvc.perform(get("/usuarios/2/bloquear").session(session))
                //.andDo(print())
                .andExpect(status().isUnauthorized());
    }

}
