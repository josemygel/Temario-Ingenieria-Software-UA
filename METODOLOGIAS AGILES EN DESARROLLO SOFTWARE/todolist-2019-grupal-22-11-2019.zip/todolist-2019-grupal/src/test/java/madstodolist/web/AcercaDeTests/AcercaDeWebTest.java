package madstodolist.web.AcercaDeTests;

import madstodolist.controller.HomeController;
import madstodolist.model.Usuario;
import madstodolist.service.UsuarioService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@RunWith(SpringRunner.class)
@WebMvcTest(HomeController.class)
public class AcercaDeWebTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UsuarioService usuarioService;

    @Test
    public void aboutPageWithLogin() throws Exception {
        Usuario usuario = new Usuario("domingo@ua.es");
        usuario.setId(1L);
        usuario.setNombre("Domingo Gallardo");

        when(usuarioService.findById(1L)).thenReturn(usuario);

        this.mockMvc.perform(get("/about"))
                //.andDo(print())
                .andExpect(content().string(containsString("Acerca de")))
                .andExpect(content().string(containsString("Versión")))
                .andExpect(content().string(containsString("ToDoList")))
                .andExpect(content().string(containsString("Fecha de release:")))
                .andExpect(content().string(containsString("Jose Miguel Gómez Lozano")));
    }

    @Test
    public void aboutPageWithoutLogin() throws Exception {

        when(usuarioService.findById(1L)).thenReturn(null);

        this.mockMvc.perform(get("/about"))
                //.andDo(print())
                .andExpect(content().string(containsString("Acerca de")))
                .andExpect(content().string(containsString("ToDoList")))
                .andExpect(content().string(containsString("Fecha de release:")));
    }
}
