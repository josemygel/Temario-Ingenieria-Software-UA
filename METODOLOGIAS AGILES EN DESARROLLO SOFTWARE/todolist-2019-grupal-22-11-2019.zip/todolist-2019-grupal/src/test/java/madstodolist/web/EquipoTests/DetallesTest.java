package madstodolist.web.EquipoTests;

import madstodolist.authentication.ManagerUserSesion;
import madstodolist.controller.EquipoController;
import madstodolist.model.Equipo;
import madstodolist.model.Usuario;
import madstodolist.service.EquipoService;
import madstodolist.service.UsuarioService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(EquipoController.class)
public class DetallesTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EquipoService equipoService;

    @MockBean
    private UsuarioService usuarioService;

    @MockBean
    private ManagerUserSesion managerUserSesion;

    @MockBean
    private MockHttpSession session;

    /**
     * TEST: Se muestra listado de usuarios solo con usuarios bloqueados
     */
    @Test
    public void vistaAdministradorDetallesEquipoOK() throws Exception {

        Usuario usuario1 = new Usuario("usuario1@ua.es");
        usuario1.setId(1L);
        usuario1.setNombre("Usuario1");
        usuario1.setBanned(true);

        Usuario usuario2 = new Usuario("usuario2@ua.es");
        usuario2.setId(2L);
        usuario2.setNombre("Usuario2");
        usuario2.setBanned(false);

        Usuario admin = new Usuario("admin@ua.es");
        admin.setId(3L);
        admin.setNombre("Admin");
        admin.setIsAdmin(true);

        Equipo equipo1 = new Equipo("Equipo1");
        equipo1.setId(1L);

        List<Usuario> usuarios = new ArrayList<Usuario>();
        usuarios.add(admin);
        usuarios.add(usuario1);
        usuarios.add(usuario2);

        managerUserSesion.logearUsuario(session,admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);

        when(equipoService.findById(1L)).thenReturn(equipo1);
        when(equipoService.usuariosEquipo(1L)).thenReturn(usuarios);

        this.mockMvc.perform(get("/equipos/1").session(session))
                //.andDo(print())
                .andExpect(content().string(containsString("Participantes del equipo " + equipo1.getNombre())))    //Aparece el titulo
                .andExpect(content().string(containsString("usuario1@ua.es")))    //Usuario1
                .andExpect(content().string(containsString("usuario2@ua.es")))    //Usuario2
                .andExpect(content().string(containsString("admin@ua.es")))    //Admin
                .andExpect(content().string(containsString("Bloquear"))); //El usuario logueado es Admin, por lo que podrá ver opcion de bloquear desde ahí
    }


    /**
     * TEST: Se muestra listado de usuarios solo con usuarios bloqueados
     */
    @Test
    public void vistaUsuarioNormalDetallesEquipoOK() throws Exception {

        Usuario usuario1 = new Usuario("usuario1@ua.es");
        usuario1.setId(1L);
        usuario1.setNombre("Usuario1");
        usuario1.setBanned(true);

        Usuario usuario2 = new Usuario("usuario2@ua.es");
        usuario2.setId(2L);
        usuario2.setNombre("Usuario2");
        usuario2.setBanned(false);

        Usuario admin = new Usuario("admin@ua.es");
        admin.setId(3L);
        admin.setNombre("Admin");
        admin.setIsAdmin(true);

        Equipo equipo1 = new Equipo("Equipo1");
        equipo1.setId(1L);

        List<Usuario> usuarios = new ArrayList<Usuario>();
        usuarios.add(admin);
        usuarios.add(usuario1);
        usuarios.add(usuario2);

        managerUserSesion.logearUsuario(session,usuario1);
        when(usuarioService.getSesion(session)).thenReturn(usuario1);
        when(usuarioService.getAdmin()).thenReturn(admin);

        when(equipoService.findById(1L)).thenReturn(equipo1);
        when(equipoService.usuariosEquipo(1L)).thenReturn(usuarios);

        this.mockMvc.perform(get("/equipos/1").session(session))
                //.andDo(print())
                .andExpect(content().string(containsString("Participantes del equipo " + equipo1.getNombre())))    //Aparece el titulo
                .andExpect(content().string(containsString("usuario1@ua.es")))    //Usuario1
                .andExpect(content().string(containsString("usuario2@ua.es")))    //Usuario2
                .andExpect(content().string(containsString("admin@ua.es")))    //Admin
                .andExpect(content().string(not(containsString("Bloquear")))); //El usuario logueado no es admin, por lo que no podrá ver opcion de bloquear
    }

    @Test
    public void servicioDesbloquearUsuarioDesdeEquipoDetalles() throws Exception {
        Usuario admin = new Usuario("admin@gmail.com");
        admin.setNombre("admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        Usuario anaGarcia = new Usuario("usuarioTest@gmail.com");
        anaGarcia.setId(2L);
        anaGarcia.setNombre("userTest");
        anaGarcia.setIsAdmin(false);
        anaGarcia.setBanned(true);

        List<Usuario> users = new ArrayList<Usuario>();
        users.add(admin);
        users.add(anaGarcia);


        managerUserSesion.logearUsuario(session, admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(equipoService.usuariosEquipo(1L)).thenReturn(users);
        when(usuarioService.findById(2L)).thenReturn(anaGarcia);
        when(usuarioService.findById(1L)).thenReturn(admin);
        //El nuevo estado es el booleano que devuelve
        when(usuarioService.bloquear(2L)).thenReturn(false);

        this.mockMvc.perform(get("/equipos/1/bloquear/2").session(session))
                //.andDo(print())
                .andExpect(flash().attribute("mensaje","¡El usuario usuarioTest@gmail.com ha sido desbloqueado correctamente!"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/equipos/1"));
    }

    @Test
    public void servicioBloquearUsuarioDesdeEquipoDetalles() throws Exception{
        Usuario admin = new Usuario("admin@gmail.com");
        admin.setNombre("admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        Usuario anaGarcia = new Usuario("usuarioTest@gmail.com");
        anaGarcia.setId(2L);
        anaGarcia.setNombre("userTest");
        anaGarcia.setIsAdmin(false);
        anaGarcia.setBanned(false);

        List<Usuario> users = new ArrayList<Usuario>();
        users.add(admin);
        users.add(anaGarcia);


        managerUserSesion.logearUsuario(session, admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(equipoService.usuariosEquipo(1L)).thenReturn(users);
        when(usuarioService.findById(2L)).thenReturn(anaGarcia);
        when(usuarioService.findById(1L)).thenReturn(admin);
        //El nuevo estado es el booleano que devuelve
        when(usuarioService.bloquear(2L)).thenReturn(true);

        this.mockMvc.perform(get("/equipos/1/bloquear/2").session(session))
                //.andDo(print())
                .andExpect(flash().attribute("mensaje","¡El usuario usuarioTest@gmail.com ha sido bloqueado correctamente!"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/equipos/1"));
    }


    /**
     * En un principio, y que no es definitivo, para simplificar este último punto, por falta de tiempo y
     * por simplicidad en las tablas de listar equipos, vamos a ofrecer el acceso a "Eliminar equipo"
     * únicamente en la vista de 'Detalles de equipo', ignorando el botón en "LISTADO DE EQUIPOS"
     *  -- Comenzaremos testeando las vistas --
     */

    @Test
    public void vistaEquipoDetallesUsuarioNormalSinGestion() throws Exception{
        // GIVEN
        Usuario usuario = new Usuario("usuario@gmail.com");
        usuario.setNombre("usuario");
        usuario.setId(1L);
        usuario.setIsAdmin(false);

        Usuario admin = new Usuario("admin@gmail.com");
        admin.setNombre("admin");
        admin.setId(2L);
        admin.setIsAdmin(true);

        Equipo equipo = new Equipo("Equipo 1");
        equipo.setId(1L);

        // WHEN
        managerUserSesion.logearUsuario(session,usuario);
        when(usuarioService.getSesion(session)).thenReturn(usuario);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findById(1L)).thenReturn(usuario);
        when(usuarioService.findById(2L)).thenReturn(admin);
        when(equipoService.findById(1L)).thenReturn(equipo);

        // THEN
        this.mockMvc.perform(get("/equipos/1").session(session))
                //.andDo(print())
                .andExpect(content().string(not(containsString("Editar equipo"))))
                .andExpect(content().string(not(containsString("Eliminar equipo")))); //El usuario logueado no es admin, por lo que no podrá gestionar el equipo

    }

    @Test
    public void vistaEquipoDetallesAdministradorConGestion() throws Exception{
        // GIVEN
        Usuario admin = new Usuario("admin@gmail.com");
        admin.setNombre("admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        Equipo equipo = new Equipo("equipo1");
        equipo.setId(1L);

        // WHEN
        managerUserSesion.logearUsuario(session,admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findById(1L)).thenReturn(admin);
        when(equipoService.findById(1L)).thenReturn(equipo);

        // THEN
        this.mockMvc.perform(get("/equipos/1").session(session))
                //.andDo(print())
                .andExpect(content().string(containsString("Editar equipo")))
                .andExpect(content().string(containsString("Eliminar equipo"))); //El usuario logueado no es admin, por lo que no podrá gestionar el equipo
    }

    /**
     * Despues de testear que los botones están en las vistas, procedemos a comprobar que redirigen correctamente
     */

    @Test
    public void servicioEliminarDetallesEquipoUsuarioNormalKO() throws Exception{
        // GIVEN
        Usuario usuario = new Usuario("usuario@gmail.com");
        usuario.setNombre("usuario");
        usuario.setId(1L);
        usuario.setIsAdmin(false);

        Usuario admin = new Usuario("admin@gmail.com");
        admin.setNombre("admin");
        admin.setId(2L);
        admin.setIsAdmin(true);

        managerUserSesion.logearUsuario(session,usuario);
        when(usuarioService.getSesion(session)).thenReturn(usuario);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findById(1L)).thenReturn(usuario);

        this.mockMvc.perform(get("/equipos/1/delete").session(session))
                //.andDo(print())
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void servicioEliminarDetallesEquipoAdministradorOK() throws Exception{
        // GIVEN
        Usuario admin = new Usuario("admin@gmail.com");
        admin.setNombre("admin");
        admin.setId(1L);
        admin.setIsAdmin(true);

        // WHEN
        managerUserSesion.logearUsuario(session,admin);
        when(usuarioService.getSesion(session)).thenReturn(admin);
        when(usuarioService.getAdmin()).thenReturn(admin);
        when(usuarioService.findById(1L)).thenReturn(admin);

        // THEN
        this.mockMvc.perform(get("/equipos/1/delete").session(session))
                //.andDo(print())
                .andExpect(flash().attribute("mensaje","Equipo eliminado correctamente"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/equipos"));
    }

}