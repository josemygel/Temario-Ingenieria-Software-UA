package madstodolist.web.UsuarioTests;

import madstodolist.authentication.ManagerUserSesion;
import madstodolist.controller.LoginController;
import madstodolist.controller.UsuarioController;
import madstodolist.model.Usuario;
import madstodolist.service.UsuarioService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest({LoginController.class, UsuarioController.class})
public class RegistroTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UsuarioService usuarioService;

    @MockBean
    private ManagerUserSesion managerUserSesion;

    @MockBean
    private MockHttpSession session;

    /**
     * TEST: un usuario va a registrarse y NO existe todavía administrador
     * */
    @Test
    public void vistaRegistroUsuarioSinAdminOK() throws Exception {

        this.mockMvc.perform(get("/registro"))
                //.andDo(print())
                .andExpect(content().string(containsString("Administrador")));
    }

    /**
     * TEST: un usuario va a registrarse y YA existe administrador
     * */
    @Test
    public void vistaRegistroUsuarioConAdminOK() throws Exception {

        when(usuarioService.existAdmin()).thenReturn(true);

        this.mockMvc.perform(get("/registro"))
                //.andDo(print())
                .andExpect(content().string(not(containsString("Administrador"))));
    }

    /**
     * TEST: registro con correo existente
     * */
    @Test
    public void servicioRegistroUsuarioYaExisteKO() throws Exception {
        Usuario a = new Usuario("a@a");
        when(usuarioService.findByEmail("a@a")).thenReturn(a);

        this.mockMvc.perform(post("/registro")
                .param("eMail","a@a"))
                //.andDo(print())
                .andExpect(content().string(containsString("El usuario a@a ya existe")));
    }

    /**
     * TEST: registro con correo incorrecto
     * */
    @Test
    public void servicioRegistroEmailIncorrectoKO() throws Exception {

        this.mockMvc.perform(post("/registro")
                .param("eMail","a"))
                //.andDo(print())
                .andExpect(content().string(containsString("Dirección de correo incorrecta")));
    }

    /**
     * TEST: registro con contraseña corta
     * */
    @Test
    public void servicioRegistroPasswordCortaKO() throws Exception {

        this.mockMvc.perform(post("/registro")
                .param("eMail","a@a")
                .param("password","1234567")
                .param("nombre","a")
                .param("fechaNacimiento","01-12-2019"))
                //.andDo(print())
                .andExpect(content().string(containsString("La contraseña debe tener al menos 8 carácteres")));
    }

    /**
     * TEST: registro sin fecha
     * */
    @Test
    public void servicioRegistroSinFechaKO() throws Exception {

        this.mockMvc.perform(post("/registro")
                .param("eMail","a@a")
                .param("password","12345678")
                .param("nombre","a"))
                //.andDo(print())
                .andExpect(content().string(containsString("La fecha de nacimiento no puede estar vacía")));
    }

    /**
     * TEST: registro sin nombre
     * */
    @Test
    public void servicioRegistroSinNombreKO() throws Exception {

        this.mockMvc.perform(post("/registro")
                .param("eMail","a@a")
                .param("password","12345678")
                .param("fechaNacimiento","01-12-2019"))
                //.andDo(print())
                .andExpect(content().string(containsString("El nombre no puede estar vacío")));
    }

    /**
     * TEST: registro correcto
     * */
    @Test
    public void servicioRegistroCorrectoOK() throws Exception {

        this.mockMvc.perform(post("/registro")
                .param("eMail","a@a")
                .param("password","12345678")
                .param("nombre","a")
                .param("fechaNacimiento","01-12-2019"))
                //.andDo(print())
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
    }

}
