/* Populate tables */
INSERT INTO usuarios (id, email, nombre, password, fecha_nacimiento, is_admin, banned) VALUES('1', 'ana.garcia@gmail.com', 'Ana García', '12345678', '2001-02-10', false, false);
INSERT INTO usuarios (id, email, nombre, password, fecha_nacimiento, is_admin, banned) VALUES('2', 'a@a.a', 'aaa', 'aaa', '2001-02-10', false, false);
INSERT INTO usuarios (id, email, nombre, password, fecha_nacimiento, is_admin, banned) VALUES('3', 'b@b.b', 'bbb', 'bbb', '2001-02-10', false, false);
INSERT INTO usuarios (id, email, nombre, password, fecha_nacimiento, is_admin, banned) VALUES('4', 'c@c.c', 'ccc', 'ccc', '2001-02-10', false, true);
INSERT INTO tareas (id, titulo, usuario_id) VALUES('1', 'Lavar coche', '1');
INSERT INTO tareas (id, titulo, usuario_id) VALUES('2', 'Renovar DNI', '1');
INSERT INTO equipos (id, nombre) VALUES('1', 'Proyecto Cobalto');
INSERT INTO equipo_usuario (fk_equipo, fk_usuario) VALUES('1', '1');
INSERT INTO equipos (id, nombre) VALUES('2', 'Proyecto Adamantium');