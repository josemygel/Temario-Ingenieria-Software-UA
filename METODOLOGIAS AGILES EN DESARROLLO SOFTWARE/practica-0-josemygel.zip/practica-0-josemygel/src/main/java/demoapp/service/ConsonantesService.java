package demoapp.service;

import org.springframework.stereotype.Service;

@Service
public class ConsonantesService {
    public String consonantes(String nombre) {
        return "Consonantes de " + nombre + " son " + nombre.replaceAll("[aeiou]", "-");
    }
}