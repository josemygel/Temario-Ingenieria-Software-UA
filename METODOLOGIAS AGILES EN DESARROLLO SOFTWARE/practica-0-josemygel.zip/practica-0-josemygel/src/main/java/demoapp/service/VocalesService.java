package demoapp.service;

import org.springframework.stereotype.Service;

@Service
public class VocalesService {
    public String vocales(String nombre) {
        return "Vocales de " + nombre + " son " + nombre.replaceAll("[^aeiou]", "-");
    }
}