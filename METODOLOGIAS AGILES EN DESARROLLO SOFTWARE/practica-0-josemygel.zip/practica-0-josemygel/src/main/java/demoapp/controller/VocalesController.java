package demoapp.controller;

import demoapp.service.VocalesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class VocalesController {

    private final VocalesService service;

    @Autowired
    public VocalesController(VocalesService service) {
        this.service = service;
    }

    @RequestMapping("/api/vocales/{nombre}")
    public @ResponseBody String vocales(@PathVariable(value="nombre") String nombre) {
        return service.vocales(nombre);
    }

}
