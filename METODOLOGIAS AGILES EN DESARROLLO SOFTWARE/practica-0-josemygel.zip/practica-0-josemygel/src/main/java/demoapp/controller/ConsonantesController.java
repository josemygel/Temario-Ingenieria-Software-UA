package demoapp.controller;

import demoapp.service.ConsonantesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class ConsonantesController {

    private final ConsonantesService service;

    @Autowired
    public ConsonantesController(ConsonantesService service) {
        this.service = service;
    }

    @RequestMapping("/api/consonantes/{nombre}")
    public @ResponseBody String saludo(@PathVariable(value="nombre") String nombre) {
        return service.consonantes(nombre);
    }

}
