package demoapp.controller;

import demoapp.service.ConsonantesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class ConsonantesControllerPlantilla {

    private final ConsonantesService service;

    @Autowired
    public ConsonantesControllerPlantilla(ConsonantesService service) {
        this.service = service;
    }

    @RequestMapping("/consonantes/{nombre}")
    public String consonantes(@PathVariable(value="nombre") String nombre, Model model) {
        model.addAttribute("mensaje", service.consonantes(nombre));
        return "consonantes";//"Necesito un nombre. Por ejemplo: /consonantesplantilla/Jose";
    }
}
