package demoapp.controller;

import demoapp.service.VocalesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class VocalesControllerPlantilla {

    private final VocalesService service;

    @Autowired
    public VocalesControllerPlantilla(VocalesService service) {
        this.service = service;
    }

    @RequestMapping("/vocales/{nombre}")
    public String vocales(@PathVariable(value="nombre") String nombre, Model model) {
        model.addAttribute("mensaje", service.vocales(nombre));
        return "vocales";//"Necesito un nombre. Por ejemplo: /vocalesplantilla/Jose";
    }
}
