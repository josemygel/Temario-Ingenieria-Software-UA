package demoapp;

import demoapp.service.ConsonantesService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ConsonantesServiceTest {

    @Autowired
    ConsonantesService consonantes;

    @Test
    public void contexLoads() throws Exception {
        assertThat(consonantes).isNotNull();
    }
    @Test
    public void serviceConsonantes() throws Exception {
        assertThat(consonantes.consonantes("Domingo")).isEqualTo("Consonantes de Domingo son D-m-ng-");
    }
}
