package demoapp;

import demoapp.service.VocalesService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest
public class VocalesServiceTest {

    @Autowired
    VocalesService vocales;

    @Test
    public void contexLoads() throws Exception {
        assertThat(vocales).isNotNull();
    }

    @Test
    public void serviceVocales() throws Exception {
        assertThat(vocales.vocales("Domingo")).isEqualTo("Vocales de Domingo son -o-i--o");
    }
}
