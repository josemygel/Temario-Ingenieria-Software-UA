#include <iostream>
#include "tabbcalendario.h"
using namespace std;

int
main(void)
{
/************************************************/
/***************** CONSTRUCTOR */
/************************************************/
  TABBCalendario a, b;

  cout << "No hace nada" << endl;

  return 0;
}
