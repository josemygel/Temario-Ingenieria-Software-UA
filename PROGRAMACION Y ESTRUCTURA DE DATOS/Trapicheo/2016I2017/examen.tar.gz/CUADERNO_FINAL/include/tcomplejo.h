#ifndef _tcom
#define _tcom

#include <iostream>
#include <cmath>


using namespace std;

class TComplejo{

	private:
		double
			re, im;

	public:
		// Forma canonica
		TComplejo  (double r=0, double i=0){re=r; im=i;}
		~TComplejo (){im=0; re=0;}
		TComplejo(const TComplejo &tc){re=tc.re; im=tc.im;}
		TComplejo &operator= (const TComplejo &tc);

		// Metodos
		TComplejo operator+ (const TComplejo &tc) const;
		TComplejo operator- (const TComplejo &tc) const;
		TComplejo operator* (const TComplejo &tc) const;
		TComplejo operator+ (const double num) const;
		TComplejo operator- (const double num) const;
		TComplejo operator* (const double num) const;

		bool operator==	(const TComplejo &tc) const;
		bool operator!=	(const TComplejo &tc) const;

		double Re() const{return re;}
		double Im() const{return im;}
		void Re(const double r) {re=r;}
		void Im(const double i) {im=i;}

		double Arg(void) const;
		double Mod(void) const;

	// Funciones amigas
	friend ostream & operator<<(ostream &os, const TComplejo &tc);
	friend TComplejo operator+(double d, const TComplejo &tc);
	friend TComplejo operator-(double d, const TComplejo &tc);
	friend TComplejo operator*(double d, const TComplejo &tc);
};
#endif
