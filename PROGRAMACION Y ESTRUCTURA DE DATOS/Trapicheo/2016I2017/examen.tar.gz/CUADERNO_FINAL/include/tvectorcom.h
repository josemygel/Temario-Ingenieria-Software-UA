
#include <iostream>

#ifndef TVECTORCOM_H_
#define TVECTORCOM_H_

using namespace std;

#include "tcomplejo.h"

class TVectorCom {
private:
	int tamano;
	TComplejo *c;
	void Copia(const TVectorCom &); //Metodo de copia
	void Tamano(int);

public:

	// Constructor por defecto
	TVectorCom ();
	// Constructor a partir de un tamaño
	TVectorCom (const int);
	// Constructor de copia
	TVectorCom (const TVectorCom &);
	// Destructor
	~TVectorCom ();
	// Sobrecarga del operador asignación
	TVectorCom& operator=(const TVectorCom &);


	//MÉTODOS
	// Sobrecarga del operador igualdad
	bool operator==(const TVectorCom &)const;
	// Sobrecarga del operador desigualdad
	bool operator!=(const TVectorCom &)const;
	// Sobrecarga del operador corchete (parte IZQUIERDA)
	TComplejo& operator[](const int);
	// Sobrecarga del operador corchete (parte DERECHA)
	TComplejo operator[](const int) const;
	// Tamaño del vector (posiciones TOTALES)
	int Tamano()const {int i=this->tamano; return i;}
	// Cantidad de posiciones OCUPADAS (TComplejo NO VACIO) en el vector
	int Ocupadas()const;
	// Devuelve TRUE si existe el TComplejo en el vector
	bool ExisteCom(const TComplejo &)const;
	// Mostrar por pantalla los elementos TComplejo del vector con PARTE REAL IGUAL
	//O POSTERIOR al argumento
	void MostrarComplejos(double)const;
	// REDIMENSIONAR el vector de TComplejo
	bool Redimensionar(int);
	//FUNCIONES AMIGAS
	// Sobrecarga del operador salida
	friend ostream & operator<<(ostream &,const TVectorCom &);

};


#endif /* TVECTORCOM_H_ */
