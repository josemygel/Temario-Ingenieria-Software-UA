

#include "tvectorcom.h"
#include <stdio.h>
#include <math.h>

using namespace std;

	void
	TVectorCom::Tamano(int tam){
		if(tam<=0){
			tamano=0;
		}else{
			tamano=tam;
		}
	}

	// Metodo privado para hacer Copias
	void
	TVectorCom::Copia(const TVectorCom &vc){
		this->~TVectorCom();
		this->Tamano(vc.tamano);
		c = new TComplejo[tamano]();

		for(int i=0; i < tamano;i++){
			c[i].operator =(vc.c[i]);
		}
	}

	// Constructor por defecto
	TVectorCom::TVectorCom (){
		this->tamano=0;
		this->c=NULL;
	}
	// Constructor a partir de un tamaño
	TVectorCom::TVectorCom (const int tam){
		if(tam<=0){
			this->tamano=0;
			this->c=NULL;
		}else{
			this->tamano=tam;
			this->c = new TComplejo[tam];
		}
	}

	// Constructor de copia
	TVectorCom::TVectorCom (const TVectorCom &vc){
		if(&vc!=NULL){
			this->tamano=vc.tamano;
			this->c = new TComplejo[vc.tamano];

			for(int i=0; i < this->Tamano();i++){
				this->c[i] = vc.c[i];
			}
		}else{
			this->~TVectorCom();
		}
	}

	// Destructor
	TVectorCom::~TVectorCom (){
		if(c!=NULL)
			delete [] c;
		this->c=NULL;
		this->tamano=0;
	}

	// Sobrecarga del operador asignación
	TVectorCom&
	TVectorCom::operator=(const TVectorCom &vc){
		if(&vc!=NULL){
			this->Copia(vc);
		}
		return *this;
	}

	// Sobrecarga del operador igualdad
	bool
	TVectorCom::operator==(const TVectorCom &vc)const{
		if(this->Tamano()==vc.Tamano()){
			if(this->Tamano()==0)
				return true;

			for(int i=0; i<this->Tamano();i++){
				if(this->c[i]!=vc.c[i])
					return false;
			}
			return true;
		}
		return false;
	}

	// Sobrecarga del operador desigualdad
	bool
	TVectorCom::operator!=(const TVectorCom &vc)const {
		return !operator ==(vc);
	}

	// Sobrecarga del operador corchete (parte IZQUIERDA)
	TComplejo&
	TVectorCom::operator[](const int i){
		TComplejo *aux = new TComplejo();
		if(i > 0 && i <= this->tamano){
			return c[i-1];
		}else{
			return *aux;
		}
	}

	// Sobrecarga del operador corchete (parte DERECHA)
	TComplejo
	TVectorCom::operator[](const int i) const{
		TComplejo *aux = new TComplejo();

		if(i > 0 && i <= this->tamano){
			return c[i-1];
		}else{
			return *aux;
		}
	}
	// Cantidad de posiciones OCUPADAS (TComplejo NO VACIO) en el vector
	int
	TVectorCom::Ocupadas()const{
		int oc = 0;
		TComplejo aux;

		for (int i = 0; i < this->Tamano(); i++) {
			if (c[i]!=aux)
				oc++;
		}

		return oc;
	}

	// Devuelve TRUE si existe el TComplejo en el vector
	bool
	TVectorCom::ExisteCom(const TComplejo &tc)const{
		for (int i = 0; i < this->Tamano(); i++){
			if(c[i]==tc)
				return true;
		}

		return false;
	}

	// Mostrar por pantalla los elementos TComplejo del vector con PARTE REAL IGUAL
	void
	TVectorCom::MostrarComplejos(double re)const{
		bool empezado = false;

		cout << "[";
		for(int i=0;i<this->tamano;i++){

			if(this->c[i].Re()==re || this->c[i].Re()==re+1){
				if(empezado){				//ASI IMPRIMIMOS UNICAMENTE SI HAY YA
					cout<<", ";				//UN ELEMENTO Y SI SE INTRODUCIRA OTRO
				}
				cout << this->c[i];
				empezado=true;
			}
		}
		cout << "]";
	}

	// REDIMENSIONAR el vector de TComplejo
	bool
	TVectorCom::Redimensionar(int dim){

		if(dim == this->Tamano() || dim <= 0){
			/*NO FUE POSIBLE REDIMENSIONAR*/
			return false;

		}else{
			/*SE COMIENZA A REDIMENSIONAR*/

			TComplejo *cAux = new TComplejo[dim]();

			for(int i=0;i<dim;i++){
				if(c!=NULL && i<this->Tamano() && this->Tamano()>0){
					cAux[i].operator =(c[i]);
				}
			}
			this->Tamano(dim);
			c=cAux;
		}

		return true;
	}

	// Sobrecarga del operador salida
	ostream& operator<< (ostream &os,const TVectorCom &vc){
		os<<"[";
		if(vc.c!=NULL){
			for(int i=0;i<vc.Tamano();i++){
				os << "(" << i+1 << ") ";
				os << vc.c[i];
				if(i+1!=vc.Tamano())
					os<<", ";
			}
		}
		os<<"]";
		return os;
	}
