#include "tavlcom.h"
using namespace std;

// Constructor por defecto
//DOBLE CONSTRUCTOR DE OBJETO(ARREGLAR) :INICIALIZADOR...
TNodoAVL::TNodoAVL() {
	fe = 0; //FACTOR EQUILIBRIO
}

// Constructor de copia
//DOBLE CONSTRUCTOR DE OBJETO(ARREGLAR) :INICIALIZADOR...
TNodoAVL::TNodoAVL(const TNodoAVL &tn) :
		item(), iz(), de() {
	fe = 0;
}

// Destructor
TNodoAVL::~TNodoAVL() {
//	item.~TComplejo();
//	de.~TAVLCom();
//	iz.~TAVLCom();
//SOBRAN, se crean automaticamente
}

// Sobrecarga del operador asignación
TNodoAVL&
TNodoAVL::operator=(const TNodoAVL &tn) {

	item.operator =(tn.item);
	de = tn.de;
	iz = tn.iz;

	return *this;
}

// AUXILIAR : Equilibrará nuestro arbol
void TAVLCom::actualizarFe() {
	if (!EsVacio())
		raiz->fe = raiz->de.Altura() - raiz->iz.Altura();

	if (!raiz->de.EsVacio())
		raiz->de.actualizarFe();

	if (!raiz->iz.EsVacio())
		raiz->iz.actualizarFe();

}
void TAVLCom::II(){
	TAVLCom A(*this),B(this->raiz->iz); //ARBOLES AUXILIARES
	TAVLCom I(B.raiz->iz),D(B.raiz->de); //ARBOLES DEL NODO IZQUIERDO

	A.raiz->iz.raiz=NULL;					//ELIMINAMOS EL NODO SOBRANTE ANTES DE BAJARLO
	raiz->de=A;								//BAJAMOS EL NODO
	raiz->item=B.raiz->item;				//DAMOS VALOR DEL NODO IZQUIERDO
	raiz->iz=I;								//AÑADIMOS EL NODO IZQUIERDO DEL NODO MOVIDO
	raiz->de.raiz->iz=D;					//AÑADIMOS EL NODO DERECHO DEL NODO MOVIDO
}
void TAVLCom::ID(){
	TAVLCom A(*this),B(this->raiz->iz), C(B.raiz->de); //ARBOLES AUXILIARES
	TAVLCom I(C.raiz->iz),D(C.raiz->de); //ARBOLES DEL NODO IZQUIERDO-DERECHO

	A.raiz->iz.raiz=NULL;					//ELIMINAMOS EL NODO SOBRANTE ANTES DE BAJARLO
	raiz->de=A;								//BAJAMOS EL NODO
	raiz->item=C.raiz->item;				//DAMOS VALOR DEL NODO IZQUIERDO
	raiz->iz.raiz->de=I;					//AÑADIMOS EL NODO IZQUIERDO DEL NODO MOVIDO
	raiz->de.raiz->iz=D;					//AÑADIMOS EL NODO DERECHO DEL NODO MOVIDO
}
void TAVLCom::DI(){
	TAVLCom A(*this),B(raiz->de), C(B.raiz->iz); //ARBOLES AUXILIARES
	TAVLCom I(C.raiz->iz),D(C.raiz->de); //ARBOLES DEL NODO IZQUIERDO

	A.raiz->de.raiz=NULL;					//ELIMINAMOS EL NODO SOBRANTE ANTES DE BAJARLO
	raiz->iz=A;								//BAJAMOS EL NODO
	raiz->item=C.raiz->item;				//DAMOS VALOR DEL NODO IZQUIERDO
	raiz->de.raiz->iz=D;					//AÑADIMOS EL NODO IZQUIERDO DEL NODO MOVIDO
	raiz->iz.raiz->de=I;					//AÑADIMOS EL NODO DERECHO DEL NODO MOVIDO
}
void TAVLCom::DD(){
	TAVLCom A(*this),B(this->raiz->de); //ARBOLES AUXILIARES							A
	TAVLCom I(B.raiz->iz),D(B.raiz->de); //ARBOLES DEL NODO IZQUIERDO					  B
//
	A.raiz->de.raiz=NULL;					//ELIMINAMOS EL NODO SOBRANTE ANTES DE BAJARLO
	raiz->iz=A;								//BAJAMOS EL NODO
	raiz->item=B.raiz->item;				//DAMOS VALOR DEL NODO IZQUIERDO
	raiz->de=D;								//AÑADIMOS EL NODO IZQUIERDO DEL NODO MOVIDO
	raiz->iz.raiz->de=I;					//AÑADIMOS EL NODO DERECHO DEL NODO MOVIDO

}
// AUXILIAR : Equilibrará nuestro arbol
void TAVLCom::fe() {
	if (raiz != NULL && !EsVacio()) {
		TAVLCom A(*this);
		TAVLCom B;
		actualizarFe();

		//COMPROBAMOS QUE EL ÁRBOL ESTÁ BIEN ESTRUCTURADO
		if (raiz->fe == -2) {			//MAS IZQUIERDA
			raiz->fe = raiz->de.Altura() - raiz->iz.Altura();
			B = raiz->iz;
			B.fe();
			if (B.raiz->fe == +1) {
				ID();
			} else if (B.raiz->fe == +2) {
				if(abs(B.raiz->de.raiz->fe)==2)
					raiz->iz.raiz->de.fe();
				else
					raiz->iz.fe();
			} else if (B.raiz->fe == -1) {
				II();
			} else if (B.raiz->fe == -2) {
				if(abs(B.raiz->iz.raiz->fe)==2)
					raiz->iz.raiz->iz.fe();
				else
					raiz->iz.fe();
			}else{
				II();
			}
		} else if (raiz->fe == +2) {    //MAS DERECHA
			raiz->fe = raiz->de.Altura() - raiz->iz.Altura();
			B = raiz->de;
			B.fe();
			if (B.raiz->fe == +1) {
				DD();
			} else if (B.raiz->fe == +2) {
				if(abs(B.raiz->de.raiz->fe)==2)
					raiz->de.raiz->de.fe();
				else
					raiz->de.fe();
			} else if (B.raiz->fe == -1) {
				DI();
			} else if (B.raiz->fe == -2) {
				if(abs(B.raiz->iz.raiz->fe)==2)
					raiz->de.raiz->iz.fe();
				else
					raiz->de.fe();
			}else{
				DD();
			}
		}
		actualizarFe();
	}
}

// AUXILIAR : Devuelve el recorrido en inorden //IRD
void TAVLCom::InordenAux(TVectorCom &v, int &pos) const {
	if(!EsVacio()){
		if (!raiz->iz.EsVacio())
			raiz->iz.InordenAux(v, pos);

		v[pos++] = raiz->item;

		if (!raiz->de.EsVacio())
			raiz->de.InordenAux(v, pos);
	}
}

// AUXILIAR : Devuelve el recorrido en preorden //RID
void TAVLCom::PreordenAux(TVectorCom &v, int &pos) const {
	if(!EsVacio()){
		v[pos++] = raiz->item;

		if (!raiz->iz.EsVacio())
			raiz->iz.PreordenAux(v, pos);

		if (!raiz->de.EsVacio())
			raiz->de.PreordenAux(v, pos);
	}
}

// AUXILIAR : Devuelve el recorrido en postorden //IDR
void TAVLCom::PostordenAux(TVectorCom &v, int &pos) const {
	if(!EsVacio()){
		if (!raiz->iz.EsVacio())
			raiz->iz.PostordenAux(v, pos);

		if (!raiz->de.EsVacio())
			raiz->de.PostordenAux(v, pos);

		v[pos++] = raiz->item;
	}
}

// Constructor por defecto
TAVLCom::TAVLCom() {
	raiz = NULL;
}

// Constructor de copia
TAVLCom::TAVLCom(const TAVLCom &tac) {
	TNodoAVL *aux = new TNodoAVL();

	if (&tac != NULL) {
		raiz = aux;
		raiz->operator =(*tac.raiz);
	} else {
		raiz = NULL;
	}
}

// Destructor
TAVLCom::~TAVLCom() {
	if (raiz != NULL)
		raiz->~TNodoAVL();
	raiz = NULL;
}

// Sobrecarga del operador asignación
TAVLCom&
TAVLCom::operator=(const TAVLCom &tac) {
	TNodoAVL *aux = new TNodoAVL();

	if (&tac != NULL && !tac.EsVacio()) {
		if (raiz == NULL)
			raiz = aux;
		raiz->item = tac.raiz->item;
		raiz->de = tac.raiz->de;
		raiz->iz = tac.raiz->iz;
	} else {
		raiz = aux;
	}
	return *this;
}

// MÉTODOS
// Sobrecarga del operador de igualdad
bool TAVLCom::operator==(const TAVLCom &tac) const {
	if (Nodos() == tac.Nodos()) {
		for (int i = 1; i <= Inorden().Tamano(); i++) {
			if (!tac.Buscar(Inorden()[i]))
				return false;
		}
		return true;
	}

	return false;
}

// Sobrecarga del operador de desigualdad
bool TAVLCom::operator!=(const TAVLCom &tac) const {
	return !operator==(tac);
}
// Devuelve TRUE si el árbol está vacío, FALSE en caso contrario
bool TAVLCom::EsVacio() const {
	TComplejo aux;
	if (raiz == NULL || raiz->item == aux) {
		return true;
	}
	return false;
}

// Inserta el elemento en el árbol
bool TAVLCom::Insertar(const TComplejo &tc) {   //IMPLEMENTAR ORDENACIÓN
	bool resultado;
	TNodoAVL *aux = new TNodoAVL();
	if (&tc == NULL || Buscar(tc))
		return false;

	if (EsVacio()) {
		raiz = aux;
		raiz->item = tc;
		resultado = true;
	} else {

		double mod, re, im = 0;
		mod = raiz->item.Mod();
		re = raiz->item.Re();
		im = raiz->item.Im();

		if (tc.Mod() > mod) {					//MODULO MAYOR
			resultado = raiz->de.Insertar(tc);
		} else if (tc.Mod() < mod) {				//MODULO MENOR
			resultado = raiz->iz.Insertar(tc);
		} else if (tc.Re() > re) {				//PARTE REAL MAYOR
			resultado = raiz->de.Insertar(tc);
		} else if (tc.Re() < re) {				//PARTE REAL MENOR
			resultado = raiz->iz.Insertar(tc);
		} else if (tc.Im() > im) {				//PARTE IMAGINARIA MAYOR
			resultado = raiz->de.Insertar(tc);
		} else {								//PARTE IMAGINARIA MENOR
			resultado = raiz->iz.Insertar(tc);
		}
	}
//	cout << "INSERTANDO: " << tc << endl;
	fe();
	return resultado;
}

// Borra el elemento en el árbol
bool TAVLCom::Borrar(const TComplejo &tc) {	//IMPLEMENTAR ORDENACIÓN
	if (&tc == NULL || EsVacio())
		return false;

//	cout << "Borrando:" << tc << endl;
	bool resultado = false;

	if (raiz->item == tc) {
		if (raiz->de.EsVacio()) {
			if (raiz->iz.EsVacio()) {
				raiz->~TNodoAVL();
				raiz = NULL;
				resultado = true;
			} else {
				raiz = raiz->iz.raiz;
				resultado = true;
			}
		} else {
			if (raiz->iz.EsVacio()) {
				raiz = raiz->de.raiz;
				resultado = true;
			} else {
				TVectorCom aux;
				aux = raiz->iz.Inorden();
				raiz->item = aux[aux.Tamano()];
				resultado = raiz->iz.Borrar(raiz->item);
			}
		}
	} else {
		resultado = (raiz->de.Borrar(tc) || raiz->iz.Borrar(tc));
	}

	fe();
	return resultado;
}

// Devuelve TRUE si el elemento está en el árbol, FALSE en caso contrario
bool TAVLCom::Buscar(const TComplejo &tc) const {
	if (EsVacio())
		return false;
	if (raiz->item == tc) {
		return true;
	} else {
		return (raiz->de.Buscar(tc) || raiz->iz.Buscar(tc));
	}
}

// Devuelve el elemento en la raíz del árbol
TComplejo TAVLCom::Raiz() const {
	TComplejo aux;
	if (raiz != NULL)
		return raiz->item;
	return aux;
}

// Devuelve la altura del árbol (la altura de un árbol vacío es 0)
int TAVLCom::Altura() const {
	if (EsVacio())
		return 0;
	if (raiz->iz.EsVacio() && raiz->de.EsVacio())
		return 1;
	return max(1 + raiz->iz.Altura(), 1 + raiz->de.Altura());
}

// Devuelve el número de nodos del árbol (un árbol vacío posee 0 Nodos)
int TAVLCom::Nodos() const {
	if (EsVacio()) {
		return 0;
	}
	if (raiz->iz.EsVacio() && raiz->de.EsVacio()) {
		return 1;
	}
	return 1 + raiz->iz.Nodos() + raiz->de.Nodos();
}

int TAVLCom::NodosHoja() const {
	if (EsVacio())
		return 0;
	if (raiz->iz.EsVacio() && raiz->de.EsVacio())
		return 1;
	return raiz->iz.NodosHoja() + raiz->de.NodosHoja();
}

// Devuelve el recorrido en inorden
TVectorCom TAVLCom::Inorden() const {
	// Posición en el vector que almacena el recorrido
	int posicion = 1;
	// Vector del tamaño adecuado para almacenar todos los nodos
	TVectorCom v(Nodos());
	InordenAux(v, posicion);
	return v;
}

// Devuelve el recorrido en preorden
TVectorCom TAVLCom::Preorden() const {
	// Posición en el vector que almacena el recorrido
	int posicion = 1;
	// Vector del tamaño adecuado para almacenar todos los nodos
	TVectorCom v(Nodos());
	PreordenAux(v, posicion);
	return v;
}

// Devuelve el recorrido en postorden
TVectorCom TAVLCom::Postorden() const {
	// Posición en el vector que almacena el recorrido
	int posicion = 1;
	// Vector del tamaño adecuado para almacenar todos los nodos
	TVectorCom v(Nodos());
	PostordenAux(v, posicion);
	return v;
}

// Sobrecarga del operador salida
ostream&
operator<<(ostream &os, const TAVLCom &tac) {
	TVectorCom aux;
	aux.operator =(tac.Inorden());
	os << aux;
	return os;
}

//Aclaraciones: Se permite amistad entre las clases TAVLCom y TNodoAVL
/**/
