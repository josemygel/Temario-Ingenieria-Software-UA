
#include "tcomplejo.h"
#include <stdio.h>
#include <math.h>

using namespace std;
	// Sobrecarga del operador asignación
	TComplejo&
	TComplejo::operator= (const TComplejo &tc){
		if(&tc!=NULL){
			re=tc.re;
			im=tc.im;
		}
		return *this;
	}

	TComplejo
	TComplejo::operator+ (const TComplejo &tc)const{
		TComplejo aux;

		aux.re = re+tc.re;
		aux.im = im+tc.im;

		if(aux.re == -0)
			aux.re=0;
		if(aux.im == -0)
			aux.im=0;

		return aux;
	}

	TComplejo
	TComplejo::operator-(const TComplejo &tc)const{
		TComplejo aux;

		aux.re = re-tc.re;
		aux.im = im-tc.im;

		if(aux.re == -0)
			aux.re=0;
		if(aux.im == -0)
			aux.im=0;

		return aux;
	}

	TComplejo
	TComplejo::operator*(const TComplejo &tc)const{
		TComplejo aux;
		//Z1*Z2 = (x1 x2 - y1 y2) + i(x1 y2 + x2 y1)
		double x1(re),x2(tc.re),y1(im),y2(tc.im);
		aux.re = (x1*x2-y1*y2);
		aux.im = (x1*y2+x2*y1);

		if(aux.re == -0)
			aux.re=0;
		if(aux.im == -0)
			aux.im=0;

		return aux;
	}

	TComplejo
	TComplejo::operator+ (double num)const{
		TComplejo tcAux;
		tcAux.re=re+num;
		tcAux.im=im;

		return tcAux;
	}
	TComplejo
	TComplejo::operator- (const double num)const{
		TComplejo tcAux;
		tcAux.re=re-num;
		tcAux.im=im;

		return tcAux;
	}
	TComplejo
	TComplejo::operator* (const double num)const{
		TComplejo tcAux;
		tcAux.re=re*num;
		tcAux.im=im*num;

		return tcAux;
	}


	// OTROS OPERADORES
	bool
	TComplejo::operator== (const TComplejo &tc)const{
		if(re==tc.re && im==tc.im)
			return true;
		else
			return false;
	}

	bool
	TComplejo::operator!= (const TComplejo &tc)const{
		return !(*this==tc);
	}

	double
	TComplejo::Arg(void)const{// Calcula el Argumento (en Radianes)
		double a=atan2(im,re);
		return a;
	}

	double
	TComplejo::Mod(void)const{ // Calcula el Módulo
		double a=sqrt(pow(re,2)+pow(im,2));
		return a;
	}

	ostream&
	operator<< (ostream &os, const TComplejo &tc){
		os << "(" << tc.re << " " << tc.im << ")";
		return os;
	}


	TComplejo
	operator+ (const double d, const TComplejo &tc){
		TComplejo tcAux;
		tcAux.re=tc.re+d;
		tcAux.im=tc.im;

		return tcAux;
	}

	TComplejo
	operator- (const double d, const TComplejo &tc){
		TComplejo tcAux;
		tcAux.re=d-tc.re;
		tcAux.im=-tc.im;

		return tcAux;
	}

	TComplejo
	operator* (const double d, const TComplejo &tc){
		TComplejo tcAux;
		tcAux.re=tc.re*d;
		tcAux.im=tc.im*d;

		return tcAux;
	}

