using namespace std;

#include "tlistacom.h"

//class TListaNodo

	//FORMA CANÓNICA
	// Constructor por defecto
	TListaNodo::TListaNodo ():e(){
		anterior=siguiente=NULL;
	}

	// Constructor de copia
	TListaNodo::TListaNodo (TListaNodo &ln):e(ln.e){
		anterior=ln.anterior;
		siguiente=ln.siguiente;
	}

	// Destructor
	TListaNodo::~TListaNodo (){
		anterior=siguiente=NULL;
		e.~TComplejo();
	}

	// Sobrecarga del operador asignación
	TListaNodo&
	TListaNodo::operator=(const TListaNodo &ln){
		e.operator =(ln.e);
		anterior=ln.anterior;
		siguiente=ln.siguiente;
		return *this;
	}



//class TListaPos

	//FORMA CANÓNICA
	// Constructor por defecto
	TListaPos::TListaPos ():pos(){
	}

	// Constructor de copia
	TListaPos::TListaPos (const TListaPos &lp):pos(lp.pos){
	}

	// Destructor
	TListaPos::~TListaPos (){
	}

	// Sobrecarga del operador asignación
	TListaPos&
	TListaPos::operator=(const TListaPos &lp){
		pos=lp.pos;
		return *this;
	}

	//MÉTODOS
	// Sobrecarga del operador igualdad
	bool
	TListaPos::operator==(TListaPos &lp){
		if(lp.pos==pos){
			return true;
		}
		return false;
	}

	// Sobrecarga del operador desigualdad
	bool
	TListaPos::operator!=(TListaPos &lp){
		return !this->operator ==(lp);
	}

	// Devuelve la posición anterior
	TListaPos
	TListaPos::Anterior(){
		TListaPos aux;
		if(pos!=NULL)
			aux.pos = pos->anterior;
		return aux;
	}

	// Devuelve la posición siguiente
	TListaPos
	TListaPos::Siguiente(){
		TListaPos aux;
		if(pos!=NULL)
			aux.pos = pos->siguiente;
		return aux;
	}

	// Devuelve TRUE si la posición no apunta a una lista, FALSE en caso contrario
	bool
	TListaPos::EsVacia()const{
		if(pos==NULL)
			return true;
		return false;
	}



//class TListaCom
	// PRIVATE METHOD
	// APOYO PARA IMPRIMIR
	void
	TListaCom::imprimir(ostream &os, TListaCom &lc)const{

		TListaNodo *q;

		q = lc.primero;

		while(q != NULL){
			os << q->e;
			q=q->siguiente;
			if(q!=NULL)
				os<<" ";
		}
	}

	//FORMA CANONICA
	// Constructor por defecto
	TListaCom::TListaCom (){
		primero=ultimo=NULL;
	}

	// Constructor de copia
	TListaCom::TListaCom (TListaCom &tc){
		primero=ultimo=NULL;
		*this=tc;
	}

	// Destructor
	TListaCom::~TListaCom (){
		TListaNodo *q;

		q = primero;

		while(primero != NULL){
			primero = primero->siguiente;
			delete q;
			q = primero;
		}

		primero = ultimo = NULL;
	}

	// Sobrecarga del operador asignación
	TListaCom&
	TListaCom::operator=(const TListaCom &tc){
		TListaNodo *aux = new TListaNodo();

		if(this != &tc){

			if(!EsVacia()){
				this->~TListaCom();
			}

			aux = tc.ultimo;

			while(aux != NULL){
				InsCabeza(aux->e);
				aux = aux->anterior;
			}
		}

		return *this;
	}


	//MÉTODOS
	// Sobrecarga del operador igualdad
	bool
	TListaCom::operator==(TListaCom &lc){
		if(primero==lc.primero && ultimo==lc.ultimo)
			return true;
		return false;
	}

	// Sobrecarga del operador desigualdad
	bool
	TListaCom::operator!=(TListaCom &lc){
		return !this->operator ==(lc);
	}

	// Sobrecarga del operador suma
	TListaCom
	TListaCom::operator+(const TListaCom &lc)const{
		TListaCom aux;
		TListaNodo *temp;


		if(primero!=NULL && &lc!=NULL && lc.ultimo!=NULL){

			aux = *this;

			temp=lc.primero;
			while(temp!=NULL){
				aux.InsertarD(temp->e,aux.Ultima());
				temp=temp->siguiente;
			}


		}

		return aux;
	}

	// Sobrecarga del operador resta
	TListaCom
	TListaCom::operator-(const TListaCom &lc)const{
		TListaCom aux;
		TListaNodo *temp;

		if(primero!=NULL && &lc!=NULL && lc.ultimo!=NULL){

			temp=ultimo;

			while(temp != NULL){

				if(lc.Buscar(temp->e) == false )
					aux.InsCabeza(temp->e);
				temp=temp->anterior;
			}


		}

		return aux;
	}

	// Devuelve true si la lista está vacía, false en caso contrario
	bool
	TListaCom::EsVacia()const{
		if(primero == NULL && ultimo == NULL)
			return true;
		else
			return false;
	}

	// Inserta el elemento en la cabeza de la lista
	bool
	TListaCom::InsCabeza(TComplejo &tc){
		TListaNodo *aux = new TListaNodo();

		if(&tc == NULL)
			return false;

		aux->e=tc;

		if(EsVacia()){
			primero=aux;
			ultimo=aux;
		}else{
			aux->siguiente=primero;
			primero->anterior=aux;
			primero=aux;
		}

		return true;
	}

	// Inserta el elemento a la izquierda de la posición indicada
	bool
	TListaCom::InsertarI(const TComplejo &tc, const TListaPos &lp){
		TListaNodo *aux = new TListaNodo();
		TListaNodo *temp = new TListaNodo();

		if(&tc == NULL || &lp == NULL)
			return false;



		temp->e.operator=(tc);
		aux=Primera().pos;

		while(aux != NULL){
			if(aux==lp.pos){
				//  ANTERIOR <----  TEMP  -----> AUX
				if(aux->anterior!=NULL)
					temp->anterior=aux->anterior;

				temp->siguiente=aux;

				//ANTERIOR---->TEMP<------AUX
				if(aux->anterior!=NULL)
					aux->anterior->siguiente=temp;

				aux->anterior=temp;

				if(primero==aux)
					primero=temp;

				return true;
			}
			aux = aux->siguiente;
		}

		return false;
	}

	// Inserta el elemento a la derecha de la posición indicada
	bool
	TListaCom::InsertarD(const TComplejo &tc, const TListaPos &lp){
		TListaNodo *aux = new TListaNodo();
		TListaNodo *temp = new TListaNodo();

		if(&tc == NULL || &lp == NULL)
			return false;



		temp->e.operator=(tc);
		aux=Primera().pos;

		while(aux != NULL){
			if(aux==lp.pos){
				//  AUX <----  TEMP  -----> SIGUIENTE
				if(aux->siguiente!=NULL)
					temp->siguiente=aux->siguiente;

				temp->anterior=aux;

				//AUX---->TEMP<------SIGUIENTE
				if(aux->siguiente!=NULL)
					aux->siguiente->anterior=temp;

				aux->siguiente=temp;
				if(ultimo==aux)
					ultimo=temp;

				return true;
			}
			aux = aux->siguiente;
		}

		return false;
	}

	// Busca y borra la primera ocurrencia del elemento
	bool
	TListaCom::Borrar(const TComplejo &tc){
		TListaNodo *q;
		TListaNodo *ante;
		TListaNodo *desp;

		q=primero;
		if(Buscar(tc)){
			while(q != NULL){
				if(q->e == tc){
					if(primero==ultimo && primero==q){	//ES EL UNICO ELEMENTO
						primero=ultimo=NULL;
					}else if(q==primero){	//ES EL PRIMER ELEMENTO
						primero=q->siguiente;
						primero->anterior=NULL;
					}else if(q==ultimo){	//ES EL ULTIMO ELEMENTO
						ultimo=q->anterior;
						ultimo->siguiente=NULL;
					}else{
						//Guardamos las posiciones anterior y siguiente
						ante=q->anterior;
						desp=q->siguiente;
						//Hacemos que la lista ya no cuente con el elemento
						ante->siguiente=desp;
						desp->anterior=ante;
					}
					delete q;
					return true;
				}
				q=q->siguiente;
			}
		}
		return false;
	}

	// Busca y borra todas las ocurrencias del elemento
	bool
	TListaCom::BorrarTodos(const TComplejo &tc){
		bool test=false;
		while(Buscar(tc)){
			test=Borrar(tc);
		}
		return test;
	}

	// Borra el elemento que ocupa la posición indicada
	bool
	TListaCom::Borrar(TListaPos &lp){
		TListaNodo *antes;
		TListaNodo *desp;
		TListaNodo *aux;
		TListaNodo *lpos;

		aux=Primera().pos;
		lpos=lp.pos;


		if(&lp == NULL || lp.pos==NULL)
			return false;


		if(Buscar(lpos->e)){
			while(aux!=NULL){
				if(lpos==aux){
					/*BORRAR POSICION*/
					antes=aux->anterior;
					desp=aux->siguiente;

					if(antes==NULL){
						primero=desp;
					}else{
						antes->siguiente=desp;
					}

					if(desp==NULL){
						ultimo=antes;
					}else{
						desp->anterior=antes;
					}

					aux->siguiente=aux->anterior=NULL;
					delete aux;
					return true;
				}
				aux=aux->siguiente;
			}
		}
		return false;
	}

	// Obtiene el elemento que ocupa la posición indicada
	TComplejo
	TListaCom::Obtener(const TListaPos &lp)const{
		TComplejo tc;
		TListaNodo *aux;

		if(&lp==NULL || lp.pos==NULL)
			return false;

		aux = primero;
		while( aux != NULL)
		{
			if( aux == lp.pos ){
				return aux->e;
			}else
				aux = aux->siguiente;
		}

		return tc;
	}

	// Devuelve true si el elemento está en la lista, false en caso contrario
	bool
	TListaCom::Buscar(const TComplejo &tc)const{
		TListaNodo *q;

		q=primero;

		while(q != NULL){
			if(q->e==tc)
				return true;
			q=q->siguiente;
		}
		return false;
	}

	// Devuelve la longitud de la lista
	int
	TListaCom::Longitud(){
		int cont=0;

		TListaNodo *q;

		q=primero;

		while(q != NULL){
			q=q->siguiente;
			cont++;
		}

		return cont;
	}

	// Devuelve la primera posición en la lista
	TListaPos
	TListaCom::Primera()const{
		TListaPos aux;
		aux.pos=primero;
		return aux;
	}

	// Devuelve la última posición en la lista
	TListaPos
	TListaCom::Ultima()const{
		TListaPos aux;
		aux.pos=ultimo;
		return aux;
	}


	//FUNCIONES AMIGAS
	// Sobrecarga del operador salida.
	ostream& operator<< (ostream &os, TListaCom &lc){

		os<<"{";
			lc.imprimir(os,lc);
		os<<"}";

		return os;
	}
