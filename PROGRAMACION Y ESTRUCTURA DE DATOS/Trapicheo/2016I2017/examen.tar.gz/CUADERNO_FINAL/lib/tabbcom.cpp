#include "tabbcom.h"

using namespace std;

// Constructor por defecto
//DOBLE CONSTRUCTOR DE OBJETO(ARREGLAR) :INICIALIZADOR...
TNodoABB::TNodoABB ():item(),iz(),de(){
}

// Constructor de copia
//DOBLE CONSTRUCTOR DE OBJETO(ARREGLAR) :INICIALIZADOR...
TNodoABB::TNodoABB (const TNodoABB &tn):item(tn.item),iz(tn.iz),de(tn.de){

}

// Destructor
TNodoABB::~TNodoABB (){
//	item.~TComplejo();
//	de.~TABBCom();
//	iz.~TABBCom();
//SOBRAN, se crean automaticamente
}

// Sobrecarga del operador asignación
TNodoABB&
TNodoABB::operator=(const TNodoABB &tn){

	item.operator =(tn.item);
	de = tn.de;
	iz = tn.iz;

	return *this;

}

// AUXILIAR : Devuelve el recorrido en inorden //IRD
void
TABBCom::InordenAux(TVectorCom &v, int &pos)const{
	if(!EsVacio()){
	if(!nodo->iz.EsVacio())
		nodo->iz.InordenAux(v,pos);

	v[pos++]=nodo->item;

	if(!nodo->de.EsVacio())
		nodo->de.InordenAux(v,pos);
	}
}

// AUXILIAR : Devuelve el recorrido en preorden //RID
void
TABBCom::PreordenAux(TVectorCom &v, int &pos)const{
	if(!EsVacio()){
	v[pos++]=nodo->item;

	if(!nodo->iz.EsVacio())
		nodo->iz.PreordenAux(v,pos);

	if(!nodo->de.EsVacio())
		nodo->de.PreordenAux(v,pos);
	}
}

// AUXILIAR : Devuelve el recorrido en postorden //IDR
void
TABBCom::PostordenAux(TVectorCom &v, int &pos)const{
	if(!EsVacio()){
	if(!nodo->iz.EsVacio())
		nodo->iz.PostordenAux(v,pos);

	if(!nodo->de.EsVacio())
		nodo->de.PostordenAux(v,pos);

	v[pos++]=nodo->item;
	}
}

// Constructor por defecto
TABBCom::TABBCom (){
	nodo = NULL;
}

// Constructor de copia
TABBCom::TABBCom (const TABBCom &tac){
	TNodoABB *aux = new TNodoABB();

	if(&tac!=NULL){
		nodo=aux;
		nodo->operator =(*tac.nodo);
	}else{
		nodo = NULL;
	}
}

// Destructor
TABBCom::~TABBCom (){
	if(nodo!=NULL)
		nodo->~TNodoABB();
	nodo=NULL;
}

// Sobrecarga del operador asignación
TABBCom&
TABBCom::operator=(const TABBCom &tac){
	TNodoABB *aux = new TNodoABB();

	if(&tac!=NULL && !tac.EsVacio()){
		if(nodo==NULL)
			nodo=aux;
		nodo->item=tac.nodo->item;
		nodo->de=tac.nodo->de;
		nodo->iz=tac.nodo->iz;
	}else{
		nodo=NULL;
	}
	return *this;
}

// MÉTODOS
// Sobrecarga del operador igualdad
bool
TABBCom::operator==(const TABBCom &tac)const{
	if(Nodos()==tac.Nodos()) {
		for(int i = 1; i <= Niveles().Tamano(); i++){
			if(!tac.Buscar(Niveles()[i]))
				return false;
		}
		return true;
	}

	return false;
}

// Devuelve TRUE si el árbol está vacío, FALSE en caso contrario
bool
TABBCom::EsVacio()const{
	if(nodo==NULL){
		return true;
	}
	return false;
}

// Inserta el elemento en el árbol
bool
TABBCom::Insertar(const TComplejo &tc){
	TNodoABB *aux = new TNodoABB();
	if(&tc==NULL || Buscar(tc))
		return false;

	if(EsVacio()){
		nodo = aux;
		nodo->item=tc;
		return true;
	}

	double mod,re,im=0;
	mod=nodo->item.Mod();
	re=nodo->item.Re();
	im=nodo->item.Im();

	if(tc.Mod()>mod){					//MODULO MAYOR
		return nodo->de.Insertar(tc);
	}else if(tc.Mod()<mod){				//MODULO MENOR
		return nodo->iz.Insertar(tc);
	}else if(tc.Re()>re){				//PARTE REAL MAYOR
		return nodo->de.Insertar(tc);
	}else if(tc.Re()<re){				//PARTE REAL MENOR
		return nodo->iz.Insertar(tc);
	}else if(tc.Im()>im){				//PARTE IMAGINARIA MAYOR
		return nodo->de.Insertar(tc);
	}else{								//PARTE IMAGINARIA MENOR
		return nodo->iz.Insertar(tc);
	}
}

// Borra el elemento en el árbol
bool
TABBCom::Borrar(const TComplejo &tc){
	if(&tc==NULL || EsVacio())
		return false;

	if(nodo->item==tc){
		if(nodo->de.EsVacio()){
			if(nodo->iz.EsVacio()){
				nodo->~TNodoABB();
				nodo=NULL;
				return true;
			}else{
				nodo=nodo->iz.nodo;
				return true;
			}
		}else{
			if(nodo->iz.EsVacio()){
				nodo=nodo->de.nodo;
				return true;
			}else{
				TVectorCom aux;
				aux=nodo->iz.Inorden();
				nodo->item=aux[aux.Tamano()];
				return nodo->iz.Borrar(nodo->item);
			}
		}
	}else{
		return (nodo->de.Borrar(tc) || nodo->iz.Borrar(tc));
	}
}

// Devuelve TRUE si el elemento está en el árbol, FALSE en caso contrario
bool
TABBCom::Buscar(const TComplejo &tc)const{
	if(EsVacio())
		return false;
	if(nodo->item==tc){
		return true;
	}else{
		return (nodo->de.Buscar(tc) || nodo->iz.Buscar(tc));
	}
}

// Devuelve el elemento en la raíz del árbol
TComplejo
TABBCom::Raiz()const{
	TComplejo aux;
	if(nodo!=NULL)
		return nodo->item;
	return aux;
}

// Devuelve la altura del árbol (la altura de un árbol vacío es 0)
int
TABBCom::Altura()const{
	if(EsVacio())
		return 0;
	if(nodo->iz.EsVacio() && nodo->de.EsVacio())
		return 1;
	return max(1 + nodo->iz.Altura(),1 + nodo->de.Altura());
}

// Devuelve el número de nodos del árbol (un árbol vacío posee 0 nodos)
int
TABBCom::Nodos()const{
	if(EsVacio()){
		return 0;
	}
	return 1 + nodo->iz.Nodos() + nodo->de.Nodos();
}

// Devuelve el número de nodos hoja en el árbol (la raíz puede ser nodo hoja)
int
TABBCom::NodosHoja()const{
	if(EsVacio())
		return 0;
	if(nodo->iz.EsVacio() && nodo->de.EsVacio())
		return 1;
	return nodo->iz.NodosHoja() + nodo->de.NodosHoja();
}

// Devuelve el recorrido en inorden
TVectorCom
TABBCom::Inorden() const{
	// Posición en el vector que almacena el recorrido
	int posicion = 1;
	// Vector del tamaño adecuado para almacenar todos los nodos
	TVectorCom v(Nodos());
	InordenAux(v, posicion);
	return v;
}

// Devuelve el recorrido en preorden
TVectorCom
TABBCom::Preorden()const{
	 // Posición en el vector que almacena el recorrido
	int posicion = 1;
	 // Vector del tamaño adecuado para almacenar todos los nodos
	TVectorCom v(Nodos());
	PreordenAux(v, posicion);
	return v;
}

// Devuelve el recorrido en postorden
TVectorCom
TABBCom::Postorden()const{
	 // Posición en el vector que almacena el recorrido
	int posicion = 1;
	 // Vector del tamaño adecuado para almacenar todos los nodos
	TVectorCom v(Nodos());
	PostordenAux(v, posicion);
	return v;
}

// Devuelve el recorrido en niveles
TVectorCom
TABBCom::Niveles()const{
	vector<TNodoABB*> vecAux;
	TVectorCom aux;

	if(Nodos()==0||EsVacio()){
		return aux;
	}

	vecAux.push_back(nodo);

	for(int posAux=0; (int)vecAux.size()<Nodos() ;posAux++){
		if(vecAux[posAux/2]->iz.nodo != NULL && posAux%2==0){
			vecAux.push_back(vecAux[posAux/2]->iz.nodo);
		}else if(vecAux[posAux/2]->de.nodo != NULL && posAux%2==1){
			vecAux.push_back(vecAux[posAux/2]->de.nodo);
		}
	}

	aux.Redimensionar(vecAux.size());

	for(int i = 0; i<(int)vecAux.size(); i++){
		aux[i+1]=vecAux[i]->item;
	}

	return aux;
}

// Sobrecarga del operador salida
ostream&
operator<<(ostream &os,const TABBCom &tac){
	TVectorCom aux;
	aux.operator =(tac.Niveles());
	os << aux;
	return os;
}

//Aclaraciones: Se permite amistad entre las clases TABBCom y TNodoABB
/**/

