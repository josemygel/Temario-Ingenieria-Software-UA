const Game = require('../models/game.model.js');

// Create and Save a new game
exports.create = (req, res) => {
};

// Retrieve and return all games from the database.
exports.findAll = (req, res) => {
};

// Find a single game with a gameId
exports.findOne = (req, res) => {

};

//El usuario mandará el resultado, generalmente (e inicialmente) será un String
exports.play = (req, res) => {
    
};

// Update a game identified by the gameId in the request
exports.update = (req, res) => {
};

// Delete a game with the specified gameId in the request
exports.delete = (req, res) => {
};
