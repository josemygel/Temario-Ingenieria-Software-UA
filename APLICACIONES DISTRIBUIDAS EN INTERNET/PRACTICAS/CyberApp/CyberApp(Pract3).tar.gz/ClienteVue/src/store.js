import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

export default new Vuex.Store({
  state:{
    // Actual estado(State) de la aplicacion se encuentra aqui.
    // Current state of the application lies here.
      _id: '',
      email: '',
      username: '',
      level: 0,
      threadSelected:{
        _id: '',
        title: '',
        content: '',
        author: {
          username: ''
        },
        category: ''
      },
      logued: false,
      loading: true,
      threads: [{
        title: String,
        content: String,
        author: {
          username: String
        },
        category: String,

      }]
   },
   getters:{
    // Obtiene el estado derivado del actual. Mas parecido a una propiedad computada.
    // Compute derived state based on the current state. More like computed property.
   },
   mutations:{
    // Muta el estado actual.
    // Mutate the current state.
    logued(state, bool){
      state.logued = bool;
    },
    loading(state, bool){
      state.loading = bool;
    },
    loadUserData(state, data){
      console.log("Call => loadUserData(state,~~"+JSON.stringify(data)+"~~)")
      //alert(JSON.stringify(data))
      if(!data.error)
      {
        state.email = data.email;
        state.username = data.username;
        state.level = data.level;
        state.logued = true;
      }else{
        state.logued = false;
      }
    },
    loadThreadsData(state, data){
      console.log("Call => loadThreadsData(state,~~"+JSON.stringify(data)+"~~)")
      //alert(JSON.stringify(data))
      if(!data.error)
      {
        state.threads = data;
      }
    },
    newThread(state, thread){
      if(state.threadSelected == thread)
        return;

      state.threadSelected._id = thread._id;
      state.threadSelected.title = thread.title;
      state.threadSelected.content = thread.content;
      state.threadSelected.author.username = thread.author.username;
      state.threadSelected.category = thread.category;
      
      //alert("The new thread selected is: " + JSON.stringify(state.threadSelected))
    }
  },
  actions:{
    selectThread(context, thread){
      context.commit('newThread',thread);
    },
    //CREADOR DE HILOS
    createThread(context){
      var title = context.state.threadSelected.title;
      var content = context.state.threadSelected.content;
      var token = localStorage.token;

      var body = {
        title: title,
        content: content
      }
      var config = {
        headers: {'Authorization': "bearer " + token, 'Content-Type':"application/json"},
        // Reject only if the status code is greater than or equal to 500
        validateStatus: function(status) { return status < 400; }
      };
      console.log("Call => getUserData(context)");
      // Get the data from server
      axios.post("http://localhost:3000/threads",body,config).then(()=>{
        alert("El hilo ha sido creado con éxito.")
        context.dispatch('getThreadsData');
      }).catch(() => { alert("Error al crear el hilo (asegurese de rellenar los campos).") })
    },

    //MODIFICADOR DE HILOS
    saveThread(context){

      var id = context.state.threadSelected._id;
      var title = context.state.threadSelected.title;
      var content = context.state.threadSelected.content;
      var token = localStorage.token;

      var body = {
        title: title,
        content: content
      }

      var config = {
        headers: {'Authorization': "bearer " + token},
        body: {
          'title': title,
          'content': content
      },
        // Reject only if the status code is greater than or equal to 500
        validateStatus: function(status) { return status < 400; }
      };
      console.log("Call => getUserData(context)");
      // Get the data from server
      axios.put("http://localhost:3000/threads/"+id,body,config).then(()=>{
        alert("El hilo ha sido actualizado con éxito.")
        context.dispatch('getThreadsData');
      }).catch(() => { alert("Error al actualizar el hilo") })
    },

    //ELIMINADOR DE HILOS
    deleteThread(context){
      if(!context.state.threadSelected._id)
      {
        alert("No existe el id del thread seleccionado...")
        return
      }
      var id = context.state.threadSelected._id;
      var token = localStorage.token;

      var config = {
        headers: {'Authorization': "bearer " + token},
        // Reject only if the status code is greater than or equal to 500
        validateStatus: function(status) { return status < 400; }
      };
      console.log("Call => getUserData(context)");
      // Get the data from server
      axios.delete("http://localhost:3000/threads/"+id,config).then(()=>{
        alert("El hilo ha sido eliminado con éxito.")

        //LIMPIAMOS EL HILO
        context.state.threadSelected._id = '';
        context.state.threadSelected.title = '';
        context.state.threadSelected.content = '';
        context.state.threadSelected.category = '';
        context.state.threadSelected.author.username = '';

        //ACTUALIZAMOS HILOS
        context.dispatch('getThreadsData');

      }).catch((err) => { alert(err) })
    },
    getAllData(context){
      //Activamos la carga
      context.commit('loading',true);

      //PAUSA DE CARGA FICTICIA DE 1.5 SEGUNDOS
      setTimeout(()=>{
        context.dispatch('getUserData');
        context.dispatch('getThreadsData');
        context.commit('loading',false);

      //Aqui marcamos el tiempo de setTimeout
      },1500);
      
    },
    // Obtiene los datos del servidor y los envia a mutaciones para mutar el estado actual.
    // Get data from server and send that to mutations to mutate the current state.
      getUserData(context,token){
        token = token || localStorage.token;
        var config = {
          headers: {'Authorization': "bearer " + token},
          // Reject only if the status code is greater than or equal to 500
          validateStatus: function(status) { return status < 400; }
        };
        console.log("Call => getUserData(context)");
        // Get the data from server
        axios.get("http://localhost:3000/me",config).then((response)=>{
          response = Array.isArray(response) ? response[0] : response;
        // commit to the store
          context.commit('loadUserData',response.data.me)
        }).catch(() => { context.commit('logued',false) })
        
      },
      getThreadsData(context){
        console.log("Call => getThreadsData(context)");
        // Get the data from server
        axios.get("http://localhost:3000/threads").then((response)=>{
          response = Array.isArray(response) ? response[0] : response;
        // commit to the store
          context.commit('loadThreadsData',response.data);
        })
      }
    }
});