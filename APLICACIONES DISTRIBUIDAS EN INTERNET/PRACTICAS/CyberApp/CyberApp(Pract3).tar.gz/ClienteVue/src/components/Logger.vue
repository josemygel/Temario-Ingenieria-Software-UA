<template>
  <div id="Logger">
    <div class="form--heading">
      <h1>
        <label style="color:white">Bienvenido a CyberApp</label>
      </h1>
    </div>
    <div class="container">
      <div class="message signin">
        <form autocomplete="off">
          <span v-if="error_username_reg">Username error: {{error_username_reg}}</span>
          <input @keyup.prevent="error_username_reg = undefined"  v-model="username_reg" type="text" placeholder="Username">
          <span v-if="error_email_reg">Email error: {{error_email_reg}}</span>
          <input @keyup.prevent="error_email_reg = undefined"  v-model="email_reg" type="email" placeholder="Email">
          <span v-if="error_password_reg">Password error: {{error_password_reg}}</span>
          <input @keyup.prevent="error_password_reg = undefined"  v-model="password_reg" type="password" placeholder="Password">
          <button class="button" @click.prevent="register">Registrarme</button>
        </form>
      </div>
      <div class="form form--signup">
        <form autocomplete="off">
          <span v-if="error_email_log">Email error: {{error_email_log}}</span>
          <input @keyup.prevent="error_email_log = undefined"  v-model="email_log" type="email" placeholder="Email">
          <span v-if="error_password_log">Password error: {{error_password_log}}</span>
          <input @keyup.prevent="error_password_log = undefined"  v-model="password_log" type="password" placeholder="Password">
          <button class="button" @click.prevent="login">Iniciar sesión</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
const axios = require('axios');


import { mapState, mapMutations, mapActions } from 'vuex';
//STORE DE VUEX, ANALIZAR PARA MANDAR EL DISPATCH EN UN METODO PARA DESPUES DE HACER EL LOGIN!!!
import store from '../store.js';

export default {
  name: "Logger",
  data() {
    return{
      error_username_reg: '',
      error_email_reg: '',
      error_password_reg: '',
      error_email_log: '',
      error_password_log: '',
      username_reg: '',
      email_reg: '',
      password_reg: '',
      email_log: '',
      password_log: ''
    }
  },
  computed:{
    ...mapState(['logued'])
  },
  methods: {
    ...mapMutations(['logued']),
    ...mapActions(['getUserData']),
    login() {
      //variable para acceder a data
      var vm = this;
      axios.post("http://localhost:3000/login",
        {
        email: this.email_log,
        password: this.password_log
        },
        {
          validateStatus: function(status) {
            return status < 500; // Reject only if the status code is greater than or equal to 500
          }
        })
        .then( function(response) {
          //Si es un array, obtenemos los datos del mismo
          response = Array.isArray(response) ? response[0] : response;

          if (response.data.token) {
            alert("Inicio de sesión correcto.")
            localStorage.token = response.data.token;
            alert("TOKEN = "+localStorage.token)
            store.dispatch('getUserData',localStorage.token);
            store.commit('logued',true);
          } else {
            vm.error_email_log = response.data.email;
            vm.error_password_log = response.data.password;
          }
        })

    },
    register() {
      //uso para acceder a sus variables?
      var vm = this;
      axios.post("http://localhost:3000/register",
        {
          username: this.username_reg,
          email: this.email_reg,
          password: this.password_reg
        },
        {
          validateStatus: function(status) {
            return status < 500; // Reject only if the status code is greater than or equal to 500
          }
        }).then(function(response) {
          //Si es un array, obtenemos los datos del mismo
          response = Array.isArray(response) ? response[0] : response;
        if (response && response.data && response.data._id)
          alert("Registro correcto, por favor inicia sesión.");
        else {
          vm.error_username_reg = response.data.username;
          vm.error_email_reg = response.data.email;
          vm.error_password_reg = response.data.password;
        }
      });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
span{
  color:red;
  font-size: 12px;
}
body,
.message,
.form,
form {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
}

.container {
  border-radius: 10px;
  border: solid #ffffff 2px;
  transform: translateX(46.5%);
  width: 700px;
  height: 340px;
  background: rgba(42, 255, 209, 0.705);
  display: grid;
  grid-template: 100% / 50% 50%;
  /*  box-shadow: 2px 2px 10px 50px rgba(#333, 0.7);*/
}

.message {
  position: absolute;
  background: rgba(179, 255, 0, 0.705);
  width: 50%;
  height: 100%;
  transition: 0.5s all ease;
  transform: translateX(100%);
  z-index: 4;
}

.message:before {
  position: absolute;
  content: "";
  width: 1px;
  height: 70%;
  background: #c3c3d8;
  opacity: 0;
  left: 0;
  top: 15%;
}

.button {
  margin: 5px 0;
}

.signup :before {
  opacity: 0.3;
  left: 0;
}

.login:before {
  opacity: 0.3;
  left: 100%;
}

.btn-wrapper {
  width: 60%;
}

.form {
  width: 100%;
  height: 100%;
}

.form--heading {
  font-size: 18px;
  height: 50px;
  color: #809bce;
  font-family: "Playfair Display", serif;
}

form {
  width: 70%;
}
input {
  width: 90%;
  border: solid rgb(168, 168, 168) 1px;
  margin-top: 4px;
  border-bottom: 1px solid rgba(#c3c3d8, 0.5);
  font-size: 13px;
  font-weight: 300;
  color: #797a9e;
  letter-spacing: 0.11em;
}
input::placeholder {
  color: #c3c3d8;
  font-size: 10px;
}

input:focus {
  outline: 0;
  border-bottom: 1px solid rgba(#809bce, 0.7);
  transition: 0.6s all ease;
}

.button {
  width: 100%;
  height: 30px;
  border: 0;
  outline: 0;
  color: white;
  font-size: 15px;
  font-weight: 300;
  position: relative;
  z-index: 3;
  letter-spacing: 2px;
  background: linear-gradient(45deg, #809bce, #9893da);
  font-family: "Playfair Display", serif;
}

@media (max-width: 750px) {
  .container {
    transform: scale(0.8);
  }
}
</style>