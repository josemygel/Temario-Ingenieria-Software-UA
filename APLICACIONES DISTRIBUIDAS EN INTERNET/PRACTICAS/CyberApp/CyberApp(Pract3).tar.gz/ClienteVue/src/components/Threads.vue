<template>
  <div class="container">
    <div class="threads">
      <h3 id="title-threads" v-if="Array.isArray(threads)">THREADS:</h3>
      <h3 id="title-threads" v-else>¡NO SE CREARON THREADS!</h3>
      <br>
      <ul id="thread"
      v-for="thread in threads"
      v-bind:key="thread._id"
      @click="selectThread(thread)">
        <b>{{thread.title}}</b><br>
        <!--{{thread.content}}<br>-->
      </ul>
    </div>
  </div>
</template>

<script>
  import { mapState, mapActions } from 'vuex';

  export default {
    name: 'Threads',
    computed:{
      ...mapState(['threads','threadSelected'])
    },
    methods:{
    ...mapActions(['selectThread']),
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

  #thread{
    padding: 10px 0px;
    background-color: #a5a5a5;
    color:black;
    margin-top: 3px;
    border-radius: 10px;
    border: solid rgb(0, 0, 0) 2px;
  }

  #thread:hover{
    background-color:rgb(27, 194, 185);
  }

  #title-threads{
    background-color: #494949;
    color:rgb(204, 204, 204);
    border-radius: 10px;
    padding: 15px;
    margin: 0;
    border: solid rgb(0, 0, 0) 2px;
  }

  .container{
    display: inline-block;
    width:30%;
    background-color:white;
    padding: 5px;
    border-radius: 15px;
  }

  ul{
    padding:0;
    margin:0;
  }
</style>
