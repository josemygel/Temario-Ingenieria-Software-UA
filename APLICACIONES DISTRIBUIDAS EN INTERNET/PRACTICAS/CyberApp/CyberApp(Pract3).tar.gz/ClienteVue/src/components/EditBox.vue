<template>
  <div class="container">
    <div id="editbox">
      
      <div>
        <h3 id="title-editbox">Edición</h3><br>

        <ul class="editbox">
          <span>Title:</span>
          <input v-if="!threadSelected._id" v-model="threadSelected.title" placeholder="Introduce el título del hilo a crear.">
          <input v-else-if="canModify()" v-model="threadSelected.title" v-text="threadSelected.title" placeholder="Introduce el títul del hilo">
          <input v-else disabled v-model="threadSelected.title" v-text="threadSelected.title">
        </ul>
        <br><br>
        <ul class="editbox">
          <span>Content:</span>
          <!--Aunque usaremos usernam!='admin', lo correcto en producción sería volver a la edición
              del servidor y que devuelva la información en la url /me, y así poder saber si eres administrador o no-->
          <textarea v-if="!threadSelected._id" v-model="threadSelected.content" placeholder="Introduce el contenido del hilo a crear."></textarea>
          <textarea v-else-if="canModify()" v-model="threadSelected.content" v-text="threadSelected.content" placeholder="Introduce el contenido del hilo"></textarea>
          <textarea v-else disabled v-model="threadSelected.content" v-text="threadSelected.content"></textarea>
        </ul>
      </div>
      <br>
      <div>
        <ul class="selection">
          <button v-if="!threadSelected._id" @click="createThread()"><b>Crear</b></button>
          <button v-else-if="canModify()" @click="saveThread()"><b>Guardar</b></button>
          <button v-else disabled><b>Guardar</b></button>
          <button v-if="canModify()" @click="deleteThread()"><b>Borrar Thread</b></button>
          <button v-else disabled><b>Borrar Thread</b></button>
          <button @click="cleanEditBox()"><b>Limpiar</b></button>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex';

export default {
  name: 'EditBox',
  computed:{
    ...mapState(['threadSelected','username']),
  },
  methods:{
    ...mapActions(['createThread','saveThread','deleteThread']),
    canModify(){
      if(!this.threadSelected._id)
        return true;

      if(this.username == 'admin')
        return true;
      
      return this.threadSelected.author.username.localeCompare(this.username) == 0;
    },
    cleanEditBox(){
      this.threadSelected._id = '';
      this.threadSelected.title = '';
      this.threadSelected.content = '';
      this.threadSelected.category = '';
      this.threadSelected.author.username = '';
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

#title-editbox{
  background-color: #494949;
  color:rgb(204, 204, 204);
  border-radius: 10px;
  padding: 15px;
  margin: 0;
  border: solid rgb(0, 0, 0) 2px;
}

.container{
  vertical-align: top;
  margin: 0% 1%;
	display: inline-block;
  width: 50%;
  background-color:white;
  padding: 5px;
  border-radius: 15px;
  
}

ul{
  padding: 0;
  margin: 0;
}

span{
  width: 15%;
  float: left;
}

input, textarea{
  float: right;
  width: 80%;
  position: relative;
}

.editbox{
  margin:10px;
}

.selection{
  display:inline-block;
}

button{
  margin: 5px 0px 5px 10px;
}
button:hover{
  background: rgb(32, 236, 226);
}
</style>
