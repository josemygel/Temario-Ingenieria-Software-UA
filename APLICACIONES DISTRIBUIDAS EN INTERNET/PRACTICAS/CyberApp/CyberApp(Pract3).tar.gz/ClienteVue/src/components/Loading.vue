<template>
  <div id="Loading">
    <div class="msgbox">
      <h1>
        <span>{{msg}}</span>
      </h1>
    </div>
    <div class="container">
      <img :src="urlImageLoading"/>
    </div>
  </div>
</template>

<script>
//Clask simple para muestra de carga
export default {
  name: "Loading",
  data: function() {
    return{
      urlImageLoading:"https://mir-s3-cdn-cf.behance.net/project_modules/disp/35771931234507.564a1d2403b3a.gif"
    }
  },
  props: {
    msg: String
  }
};
</script>

<style scoped>
#Loading{
  color:rgb(0, 0, 0);
  transform: translateY(50%);
}
</style>