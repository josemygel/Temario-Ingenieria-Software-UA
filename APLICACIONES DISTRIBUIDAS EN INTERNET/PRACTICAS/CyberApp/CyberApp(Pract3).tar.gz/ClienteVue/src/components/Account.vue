<template>
  <div class="container">
    <div class="account">
      <h3 id="title-account">Cuenta:</h3>
      <br>
      <ul class="username">
        <b>Usuario:</b> {{username}}
      </ul>
      <ul class="email">
        <b>Email:</b> {{email}}
      </ul>
      <ul class="level">
        <b>Nivel:</b> {{level}}
      </ul>
      <button @click="close()"><b>Cerrar Sesion</b></button>
    </div>
  </div>
</template>

<script>
  import { mapState, mapActions } from 'vuex';

  export default {
    name: 'Account',
    computed:{
      ...mapState(['username','email','level'])
    },
    methods:{
      ...mapActions(['getUserData']),
      close(){
        localStorage.token = null;
        this.getUserData();
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  #thread{
    background-color: #a5a5a5;
    color:black;
    margin-top:2px;
    border-radius: 10px;
    border: solid rgb(0, 0, 0) 2px;
  }

  #thread:hover{
    background-color:rgb(27, 194, 185);
  }

  #title-account{
    background-color: #494949;
    color:rgb(204, 204, 204);
    border-radius: 10px;
    padding: 15px;
    margin: 0;
    border: solid rgb(0, 0, 0) 2px;
  }

  .container{
    vertical-align: top;
    display: inline-block;
    width:15%;
    background-color:white;
    padding: 5px;
    border-radius: 15px;
  }

  ul{
    padding:0;
    margin:0;
  }

button{
  margin: 5px 0px 5px 10px;
}
button:hover{
  background: rgb(32, 236, 226);
}
</style>
