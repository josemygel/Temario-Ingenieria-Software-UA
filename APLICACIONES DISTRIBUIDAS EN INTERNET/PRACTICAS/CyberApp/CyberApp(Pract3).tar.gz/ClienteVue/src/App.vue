<!--Template que contiene el logo de Vue y el COMPONENTE HelloWord (Los componentes se guardan en components)-->
<template>
  <div id="app">
    <!--Si loading es false, entonces se acabó la carga de la web, por lo que procedemos a mostrar los datos-->
    <Loading v-if="loading" msg="Cargando..."><!--Pagina que se muestra durante la carga--></Loading>

    <!--
    TODO: Aqui entra todo lo que desarrollaremos en la app, debemos meter aqui varios componentes: Threads, ThreadVisor, InfoUser...
    <SPA v-else-if="logued"><!- -En esta pagina entra TODO el contenido de la página web SPA- ->
    -->
    <!--EXAMPLE <Threads v-else-if="logued && email" msg="HolaMuyBuenas"> -->
    <div id="SPA" v-else-if="logued">
      <Threads><!--Threads debe cambiar, debería contener la pagina de inicio SPA básica de logueo--></Threads>
      <EditBox><!--Caja en la que se editan, crean y borran los hilos--></EditBox>
      <Account><!--Zona en la que sale la información del usuario--></Account>
    </div>
    <div id="SESION" v-else>
      <Logger><!--Aqui va el contenido--></Logger>
    </div>
  </div>
</template>


<!--Script que importa a HelloWorld, el cual esta en la carpeta indicada-->
<script>
import Threads from './components/Threads';
import EditBox from './components/EditBox';
import Account from './components/Account';
import Logger from './components/Logger';
import Loading from './components/Loading';
//En este import vamos a obtener todos los parametros mapeados del Store
import store from './store.js';

//Disparamos la obtencion de datos del usuario (Para insertar datos en el Status del Store)
store.dispatch('getAllData');
import { mapState, mapMutations, mapActions, mapGetters } from 'vuex'
//import axios from 'axios'; 

//import HelloWorld from './components/HelloWorld.vue';

export default {
  name: 'app',
  computed:{
    ...mapState(['email','username','level','threads','logued','loading','finalLogin']),
    ...mapGetters([])
  },
  methods:{
    ...mapMutations(['updateName']),
    ...mapActions(['getUserData','getAllData'])
  },
  components: {
    //Componente de SESION
    Logger,
    
    //Componentes de SPA
    Threads,
    EditBox,
    Account,

    //Componente de CARGA de SPA/SESION
    Loading
  }
}
</script>

<!--Style, aqui va todo el CSS que introducimos al id="app" del index.html-->
<style>
body {
  background: url("http://2.bp.blogspot.com/-shoZpaGpXCI/UdeuIXdICEI/AAAAAAAAW6Y/FFnuh3p9C4A/s1600/Arch+Linux+Wallpapers+%25283%2529.jpg") no-repeat center center fixed;
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  /*margin-top: 60px;*/
}

#SPA {
  width:100%;
}
</style>
