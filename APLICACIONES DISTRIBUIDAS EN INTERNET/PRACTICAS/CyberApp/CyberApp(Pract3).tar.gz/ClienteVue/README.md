### Compiles and hot-reloads for development
npm run serve


La practica realizada trata sobre hilos enuna simulación de foro.

Puntos implementados:

Requisitos mínimos:
    Login/logout
    Listado de datos
    Creación de items

Requisitos adicionales:
    1 punto si usáis CSS propio
    1 punto: implementar el listado de otro recurso incluyendo también “ver detalles” y “eliminar”. (Aunque no se hayan implementado otros, los que hay se pueden borrar).
    1 punto: edición de datos: cada elemento del listado debería tener un botón o enlace “editar” para cambiar su contenido. Al pulsarlo aparecerá un formulario para escribir los nuevos datos. Dónde y cómo aparezca (y desaparezca al acabar la edición) queda a vuestra elección. (Para editar pulsar Guardar).
    2 puntos: usar una librería para gestionar el estado de vuestra aplicación de manera centralizada. Para Vue he usado Vuex.