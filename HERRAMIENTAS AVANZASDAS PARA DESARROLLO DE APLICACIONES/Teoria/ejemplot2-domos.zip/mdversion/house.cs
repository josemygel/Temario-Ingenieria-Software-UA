
namespace Domos
{
      
    using System;
    using System.Collections.Generic;
    
    public class House {
        #region Ctor & Destructor
        /// <summary>
        /// Standard Constructor, has maxl lights and maxd doors.
        /// </summary>
        public House(int maxl, int maxd) {
            rg = new Random ();
            lal = new List<Light> ();
            dal = new List<Door> ();

            var nl = rg.Next(maxl); // number of lights
            for (int l = 0; l < nl; l++) {
                var lgt = new Light("light: " + l.ToString());
                lal.Add (lgt);
                lgt.statusChanged += itemStatusChanged;
                lgt.toggle ();
            }

            Console.WriteLine ("\n------------------\n");
            
            var nd = rg.Next(maxd); // number of doors
            for (int d = 0; d < nd; d++) {
                var door = new Door("door: " + d.ToString());
                dal.Add (door);
                door.statusChanged += itemStatusChanged;
                door.toggle ();
            }

            Console.WriteLine ("\n\nDomotic House built.");
        }

        /// <summary>
        /// Default Destructor
        /// </summary>    
        ~House() { }
        #endregion
        
        public void showAssets () {
            
            Console.WriteLine ("\nDomotic House assets\n====================");
            Console.WriteLine ("\nLights\n======");
            for (var l = 0; l < lal.Count; l++)
                Console.WriteLine ("Light n#[{0}] is {1}.", l, lal[l].st);
            Console.WriteLine ("\nDoors\n======");
            for (var d = 0; d < dal.Count; d++)
                Console.WriteLine ("Door n#[{0}] is {1}.", d, dal[d].st);
        }

        private void itemStatusChanged (object sender, StatusChangeArgs e) {
            FlipFlop ff = (FlipFlop) sender;

            Console.WriteLine ("Object [{0}] status changed to: [{1}].", ff.name, e.status);
        }
        
        private Random rg;
        private List<Light> lal;
        private List<Door> dal;
    }
}
