
namespace Domos
{
    class Door : FlipFlop {
        public Door (string n) : base (n) {
            System.Console.WriteLine ("Door built.");
        }
    }
}
